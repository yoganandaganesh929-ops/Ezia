import asyncio, base64, json, os, subprocess, time, urllib.request
import websockets

CHROME_PATH = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
PORT = 9226
USER_DATA = r"C:\temp\chrome_e2e_verification_profile"
ARTIFACT_DIR = r"C:\Users\kalwa\.gemini\antigravity\brain\bf2a4ac8-a660-4c32-afc2-0ec0609314ce"

async def run_full_verification():
    cmd = [
        CHROME_PATH,
        f"--remote-debugging-port={PORT}",
        f"--user-data-dir={USER_DATA}",
        "--headless=new",
        "--disable-gpu",
        "--window-size=1280,900",
        "--no-first-run",
        "--no-default-browser-check"
    ]
    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    for _ in range(20):
        try:
            with urllib.request.urlopen(f"http://localhost:{PORT}/json/version", timeout=1) as r:
                break
        except Exception:
            await asyncio.sleep(0.5)

    pages = [
        ("index.html", "landing"),
        ("login.html", "login"),
        ("register.html", "register"),
        ("dashboard.html", "dashboard"),
        ("calculator.html", "calculator"),
        ("hydration.html", "hydration"),
        ("sleep.html", "sleep"),
        ("insights.html", "insights"),
        ("history.html", "history"),
        ("settings.html", "settings")
    ]

    results = {}

    for page_file, page_key in pages:
        page_url = f"http://localhost:8080/{page_file}"
        print(f"\n--- AUDITING {page_file} ---")

        req = urllib.request.Request(f"http://localhost:{PORT}/json/new?{page_url}", method="PUT")
        with urllib.request.urlopen(req) as r:
            target = json.loads(r.read().decode())

        console_errors = []
        network_errors = []

        async with websockets.connect(target.get("webSocketDebuggerUrl")) as ws:
            msg_id = 1
            async def send(method, params=None):
                nonlocal msg_id
                m = {"id": msg_id, "method": method, "params": params or {}}
                msg_id += 1
                await ws.send(json.dumps(m))
                return m["id"]

            async def wait_for_resp(req_id):
                while True:
                    resp = json.loads(await ws.recv())
                    if resp.get("id") == req_id:
                        return resp.get("result", {})

            await send("Page.enable")
            await send("Runtime.enable")
            await send("Network.enable")
            await send("Page.navigate", {"url": page_url})

            start_t = time.time()
            while time.time() - start_t < 1.5:
                try:
                    resp = await asyncio.wait_for(ws.recv(), timeout=0.3)
                    ev = json.loads(resp)
                    if ev.get("method") == "Runtime.consoleAPICalled" and ev.get("params", {}).get("type") == "error":
                        console_errors.append(" ".join([str(a.get("value", "")) for a in ev.get("params", {}).get("args", [])]))
                    elif ev.get("method") == "Runtime.exceptionThrown":
                        console_errors.append(ev.get("params", {}).get("exceptionDetails", {}).get("text", ""))
                    elif ev.get("method") == "Network.responseReceived" and ev.get("params", {}).get("response", {}).get("status", 200) >= 400:
                        network_errors.append(ev.get("params", {}).get("response", {}).get("url"))
                except asyncio.TimeoutError:
                    pass

            # Capture screenshot
            ss_id = await send("Page.captureScreenshot", {"format": "png"})
            ss_res = await wait_for_resp(ss_id)
            ss_path = os.path.join(ARTIFACT_DIR, f"{page_key}_screenshot.png")
            with open(ss_path, "wb") as f:
                f.write(base64.b64decode(ss_res.get("data", "")))

            results[page_key] = {
                "file": page_file,
                "console_errors": console_errors,
                "network_errors": network_errors,
                "screenshot": ss_path
            }

            print(f"  Console Errors ({len(console_errors)}):", console_errors)
            print(f"  Network Errors ({len(network_errors)}):", network_errors)
            print(f"  Screenshot:", ss_path)

    # Specific interaction verification:
    print("\n--- RUNNING CROSS-PAGE WORKFLOW INTERACTIONS ---")

    # 1. Test Dashboard Quick-Add Water
    req_dash = urllib.request.Request("http://localhost:{PORT}/json/new?http://localhost:8080/dashboard.html".format(PORT=PORT), method="PUT")
    with urllib.request.urlopen(req_dash) as r:
        target_dash = json.loads(r.read().decode())

    async with websockets.connect(target_dash.get("webSocketDebuggerUrl")) as ws:
        msg_id = 1
        async def send_d(method, params=None):
            nonlocal msg_id
            m = {"id": msg_id, "method": method, "params": params or {}}
            msg_id += 1
            await ws.send(json.dumps(m))
            return m["id"]

        async def wait_d(req_id):
            while True:
                resp = json.loads(await ws.recv())
                if resp.get("id") == req_id:
                    return resp.get("result", {})

        await send_d("Page.enable")
        await send_d("Runtime.enable")
        await send_d("Page.navigate", {"url": "http://localhost:8080/dashboard.html"})
        await asyncio.sleep(1.0)

        # Click +250 ml button
        eval_click = await send_d("Runtime.evaluate", {
            "expression": """(() => {
                const btn = document.getElementById('quickLogWaterBtn');
                btn.click();
                const waterVal = document.getElementById('metricWaterVal').textContent;
                return { waterVal };
            })()""",
            "returnByValue": True
        })
        dash_interact_res = (await wait_d(eval_click)).get("result", {}).get("value", {})
        print("Dashboard Quick-Add Result:", dash_interact_res)
        results["dashboard_interaction"] = dash_interact_res

    # 2. Test Sleep Calculation on sleep.html
    req_sleep = urllib.request.Request("http://localhost:{PORT}/json/new?http://localhost:8080/sleep.html".format(PORT=PORT), method="PUT")
    with urllib.request.urlopen(req_sleep) as r:
        target_sleep = json.loads(r.read().decode())

    async with websockets.connect(target_sleep.get("webSocketDebuggerUrl")) as ws:
        msg_id = 1
        async def send_s(method, params=None):
            nonlocal msg_id
            m = {"id": msg_id, "method": method, "params": params or {}}
            msg_id += 1
            await ws.send(json.dumps(m))
            return m["id"]

        async def wait_s(req_id):
            while True:
                resp = json.loads(await ws.recv())
                if resp.get("id") == req_id:
                    return resp.get("result", {})

        await send_s("Page.enable")
        await send_s("Runtime.enable")
        await send_s("Page.navigate", {"url": "http://localhost:8080/sleep.html"})
        await asyncio.sleep(1.0)

        # Submit sleep entry (23:00 to 07:30)
        eval_sleep = await send_s("Runtime.evaluate", {
            "expression": """(() => {
                const bInp = document.getElementById('bedtimeInput');
                const wInp = document.getElementById('wakeTimeInput');
                bInp.value = '22:30';
                wInp.value = '07:00';
                document.getElementById('sleepForm').dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
                const heroDur = document.getElementById('heroSleepDuration').textContent;
                return { heroDur };
            })()""",
            "returnByValue": True
        })
        sleep_interact_res = (await wait_s(eval_sleep)).get("result", {}).get("value", {})
        print("Sleep Form Submission Result:", sleep_interact_res)
        results["sleep_interaction"] = sleep_interact_res

    # 3. Test Calculator Pediatric Warning
    req_calc = urllib.request.Request("http://localhost:{PORT}/json/new?http://localhost:8080/calculator.html".format(PORT=PORT), method="PUT")
    with urllib.request.urlopen(req_calc) as r:
        target_calc = json.loads(r.read().decode())

    async with websockets.connect(target_calc.get("webSocketDebuggerUrl")) as ws:
        msg_id = 1
        async def send_c(method, params=None):
            nonlocal msg_id
            m = {"id": msg_id, "method": method, "params": params or {}}
            msg_id += 1
            await ws.send(json.dumps(m))
            return m["id"]

        async def wait_c(req_id):
            while True:
                resp = json.loads(await ws.recv())
                if resp.get("id") == req_id:
                    return resp.get("result", {})

        await send_c("Page.enable")
        await send_c("Runtime.enable")
        await send_c("Page.navigate", {"url": "http://localhost:8080/calculator.html"})
        await asyncio.sleep(1.0)

        # Enter minor age 16 and calculate
        eval_calc = await send_c("Runtime.evaluate", {
            "expression": """(() => {
                document.getElementById('heightCmInput').value = '165';
                document.getElementById('weightKgInput').value = '55';
                document.getElementById('ageInput').value = '16';
                document.getElementById('calcForm').dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
                const bmrText = document.getElementById('resultBmrNum').textContent;
                const warningDisplay = document.getElementById('pediatricWarningBanner').style.display;
                const catText = document.getElementById('resultCategoryBadge').textContent;
                return { bmrText, warningDisplay, catText };
            })()""",
            "returnByValue": True
        })
        calc_interact_res = (await wait_c(eval_calc)).get("result", {}).get("value", {})
        print("Calculator Pediatric Guard Result:", calc_interact_res)
        results["calculator_interaction"] = calc_interact_res

    proc.kill()
    print("\n=== COMPLETE VERIFICATION SUMMARY ===")
    print(json.dumps(results, indent=2))

if __name__ == "__main__":
    asyncio.run(run_full_verification())
