import asyncio, base64, json, os, subprocess, time, urllib.request
import websockets

CHROME_PATH = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
PORT = 9225
USER_DATA = r"C:\temp\chrome_auth_audit_profile_2"
ARTIFACT_DIR = r"C:\Users\kalwa\.gemini\antigravity\brain\bf2a4ac8-a660-4c32-afc2-0ec0609314ce"

async def run_audit():
    cmd = [
        CHROME_PATH,
        f"--remote-debugging-port={PORT}",
        f"--user-data-dir={USER_DATA}",
        "--headless=new",
        "--disable-gpu",
        "--window-size=1280,900",
        "--no-first-run",
        "--no-default-browser-check"
    ]
    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    # Wait for CDP
    for _ in range(20):
        try:
            with urllib.request.urlopen(f"http://localhost:{PORT}/json/version", timeout=1) as r:
                break
        except Exception:
            await asyncio.sleep(0.5)

    test_results = {}

    # 1. Audit Landing Page
    print("\n--- 1. AUDITING LANDING PAGE ---")
    req1 = urllib.request.Request(f"http://localhost:{PORT}/json/new?http://localhost:8080/index.html", method="PUT")
    with urllib.request.urlopen(req1) as r:
        target1 = json.loads(r.read().decode())
    
    console_errors_1 = []
    network_errors_1 = []

    async with websockets.connect(target1.get("webSocketDebuggerUrl")) as ws:
        msg_id = 1
        async def send(method, params=None):
            nonlocal msg_id
            m = {"id": msg_id, "method": method, "params": params or {}}
            msg_id += 1
            await ws.send(json.dumps(m))
            return m["id"]

        async def wait_for_resp(req_id):
            while True:
                resp = json.loads(await ws.recv())
                if resp.get("id") == req_id:
                    return resp.get("result", {})

        await send("Page.enable")
        await send("Runtime.enable")
        await send("Network.enable")
        await send("Page.navigate", {"url": "http://localhost:8080/index.html"})

        start_t = time.time()
        while time.time() - start_t < 1.5:
            try:
                resp = await asyncio.wait_for(ws.recv(), timeout=0.3)
                ev = json.loads(resp)
                if ev.get("method") == "Runtime.consoleAPICalled" and ev.get("params", {}).get("type") == "error":
                    console_errors_1.append(" ".join([str(a.get("value", "")) for a in ev.get("params", {}).get("args", [])]))
                elif ev.get("method") == "Network.responseReceived" and ev.get("params", {}).get("response", {}).get("status", 200) >= 400:
                    network_errors_1.append(ev.get("params", {}).get("response", {}).get("url"))
            except asyncio.TimeoutError:
                pass

        ss_id = await send("Page.captureScreenshot", {"format": "png"})
        ss_res = await wait_for_resp(ss_id)
        landing_ss = os.path.join(ARTIFACT_DIR, "landing_screenshot.png")
        with open(landing_ss, "wb") as f:
            f.write(base64.b64decode(ss_res.get("data", "")))

    print(f"Landing Console Errors ({len(console_errors_1)}):", console_errors_1)
    print(f"Landing Network Errors ({len(network_errors_1)}):", network_errors_1)
    print(f"Landing Screenshot saved:", landing_ss)
    test_results["landing"] = {
        "console_errors": console_errors_1,
        "network_errors": network_errors_1,
        "screenshot": landing_ss
    }

    # 2. Audit Login Page
    print("\n--- 2. AUDITING LOGIN PAGE ---")
    req2 = urllib.request.Request(f"http://localhost:{PORT}/json/new?http://localhost:8080/login.html", method="PUT")
    with urllib.request.urlopen(req2) as r:
        target2 = json.loads(r.read().decode())

    console_errors_2 = []
    network_errors_2 = []
    login_val_res = {}

    async with websockets.connect(target2.get("webSocketDebuggerUrl")) as ws:
        msg_id = 1
        async def send2(method, params=None):
            nonlocal msg_id
            m = {"id": msg_id, "method": method, "params": params or {}}
            msg_id += 1
            await ws.send(json.dumps(m))
            return m["id"]

        async def wait_for_resp2(req_id):
            while True:
                resp = json.loads(await ws.recv())
                if resp.get("id") == req_id:
                    return resp.get("result", {})

        await send2("Page.enable")
        await send2("Runtime.enable")
        await send2("Network.enable")
        await send2("Page.navigate", {"url": "http://localhost:8080/login.html"})

        start_t = time.time()
        while time.time() - start_t < 1.5:
            try:
                resp = await asyncio.wait_for(ws.recv(), timeout=0.3)
                ev = json.loads(resp)
                if ev.get("method") == "Runtime.consoleAPICalled" and ev.get("params", {}).get("type") == "error":
                    console_errors_2.append(" ".join([str(a.get("value", "")) for a in ev.get("params", {}).get("args", [])]))
                elif ev.get("method") == "Network.responseReceived" and ev.get("params", {}).get("response", {}).get("status", 200) >= 400:
                    network_errors_2.append(ev.get("params", {}).get("response", {}).get("url"))
            except asyncio.TimeoutError:
                pass

        eval_id = await send2("Runtime.evaluate", {
            "expression": """(() => {
                const btn = document.getElementById('submitBtn');
                btn.click();
                const emailErr = document.getElementById('emailError').textContent;
                const passErr = document.getElementById('passwordError').textContent;
                return { emailErr, passErr };
            })()""",
            "returnByValue": True
        })
        login_val_res = (await wait_for_resp2(eval_id)).get("result", {}).get("value", {})

        ss_id = await send2("Page.captureScreenshot", {"format": "png"})
        ss_res = await wait_for_resp2(ss_id)
        login_ss = os.path.join(ARTIFACT_DIR, "login_screenshot.png")
        with open(login_ss, "wb") as f:
            f.write(base64.b64decode(ss_res.get("data", "")))

    print(f"Login Console Errors ({len(console_errors_2)}):", console_errors_2)
    print(f"Login Network Errors ({len(network_errors_2)}):", network_errors_2)
    print(f"Login Validation Test:", login_val_res)
    print(f"Login Screenshot saved:", login_ss)
    test_results["login"] = {
        "console_errors": console_errors_2,
        "network_errors": network_errors_2,
        "validation_test": login_val_res,
        "screenshot": login_ss
    }

    # 3. Audit Register Page
    print("\n--- 3. AUDITING REGISTER PAGE ---")
    req3 = urllib.request.Request(f"http://localhost:{PORT}/json/new?http://localhost:8080/register.html", method="PUT")
    with urllib.request.urlopen(req3) as r:
        target3 = json.loads(r.read().decode())

    console_errors_3 = []
    network_errors_3 = []
    reg_val_res = {}

    async with websockets.connect(target3.get("webSocketDebuggerUrl")) as ws:
        msg_id = 1
        async def send3(method, params=None):
            nonlocal msg_id
            m = {"id": msg_id, "method": method, "params": params or {}}
            msg_id += 1
            await ws.send(json.dumps(m))
            return m["id"]

        async def wait_for_resp3(req_id):
            while True:
                resp = json.loads(await ws.recv())
                if resp.get("id") == req_id:
                    return resp.get("result", {})

        await send3("Page.enable")
        await send3("Runtime.enable")
        await send3("Network.enable")
        await send3("Page.navigate", {"url": "http://localhost:8080/register.html"})

        start_t = time.time()
        while time.time() - start_t < 1.5:
            try:
                resp = await asyncio.wait_for(ws.recv(), timeout=0.3)
                ev = json.loads(resp)
                if ev.get("method") == "Runtime.consoleAPICalled" and ev.get("params", {}).get("type") == "error":
                    console_errors_3.append(" ".join([str(a.get("value", "")) for a in ev.get("params", {}).get("args", [])]))
                elif ev.get("method") == "Network.responseReceived" and ev.get("params", {}).get("response", {}).get("status", 200) >= 400:
                    network_errors_3.append(ev.get("params", {}).get("response", {}).get("url"))
            except asyncio.TimeoutError:
                pass

        eval_id3 = await send3("Runtime.evaluate", {
            "expression": """(() => {
                const btn = document.getElementById('regSubmitBtn');
                btn.click();
                const nameErr = document.getElementById('nameError').textContent;
                const emailErr = document.getElementById('emailError').textContent;
                return { nameErr, emailErr };
            })()""",
            "returnByValue": True
        })
        reg_val_res = (await wait_for_resp3(eval_id3)).get("result", {}).get("value", {})

        ss_id3 = await send3("Page.captureScreenshot", {"format": "png"})
        ss_res3 = await wait_for_resp3(ss_id3)
        reg_ss = os.path.join(ARTIFACT_DIR, "register_screenshot.png")
        with open(reg_ss, "wb") as f:
            f.write(base64.b64decode(ss_res3.get("data", "")))

    print(f"Register Console Errors ({len(console_errors_3)}):", console_errors_3)
    print(f"Register Network Errors ({len(network_errors_3)}):", network_errors_3)
    print(f"Register Validation Test:", reg_val_res)
    print(f"Register Screenshot saved:", reg_ss)
    test_results["register"] = {
        "console_errors": console_errors_3,
        "network_errors": network_errors_3,
        "validation_test": reg_val_res,
        "screenshot": reg_ss
    }

    proc.kill()
    print("\n=== COMPLETE AUDIT & VERIFICATION RESULTS ===")
    print(json.dumps(test_results, indent=2))

if __name__ == "__main__":
    asyncio.run(run_audit())
