import re, os

pairs = [
    ('index.html', 'index.js'),
    ('login.html', 'login.js'),
    ('register.html', 'register.js'),
    ('dashboard.html', 'dashboard.js'),
    ('calculator.html', 'calculator.js'),
    ('hydration.html', 'hydration.js'),
    ('sleep.html', 'sleep.js'),
    ('insights.html', 'insights.js'),
    ('history.html', 'history.js'),
    ('settings.html', 'settings.js'),
]

print("=== CHECKING BACKUP PRE-FRAMER ===")
for html, js in pairs:
    with open(f'_backup_pre_framer_redesign/{html}', encoding='utf-8') as hf, open(f'_backup_pre_framer_redesign/{js}', encoding='utf-8') as jf:
        h_text = hf.read()
        j_text = jf.read()
    
    get_ids = re.findall(r'document\.getElementById\([\'"]([^\'"]+)[\'"]\)', j_text)
    missing = []
    for gid in set(get_ids):
        pattern = r'id=[\'"]' + re.escape(gid) + r'[\'"]'
        if not re.search(pattern, h_text):
            missing.append(gid)
    
    if missing:
        print(f'MISMATCH in {html} <-> {js}: {missing}')
    else:
        print(f'OK: {html} <-> {js} all {len(set(get_ids))} IDs match')

print("\n=== CHECKING CURRENT VERSION ===")
for html, js in pairs:
    with open(html, encoding='utf-8') as hf, open(js, encoding='utf-8') as jf:
        h_text = hf.read()
        j_text = jf.read()
    
    get_ids = re.findall(r'document\.getElementById\([\'"]([^\'"]+)[\'"]\)', j_text)
    missing = []
    for gid in set(get_ids):
        pattern = r'id=[\'"]' + re.escape(gid) + r'[\'"]'
        if not re.search(pattern, h_text):
            missing.append(gid)
    
    if missing:
        print(f'MISMATCH in {html} <-> {js}: {missing}')
    else:
        print(f'OK: {html} <-> {js} all {len(set(get_ids))} IDs match')
