import asyncio, json, subprocess, urllib.request
import websockets

CHROME_PATH = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
PORT = 9223
USER_DATA = r"C:\temp\chrome_facade_profile"

async def test_facade():
    cmd = [
        CHROME_PATH,
        f"--remote-debugging-port={PORT}",
        f"--user-data-dir={USER_DATA}",
        "--headless=new",
        "--disable-gpu",
        "--no-first-run",
        "--no-default-browser-check"
    ]
    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    # Wait for CDP
    for _ in range(20):
        try:
            with urllib.request.urlopen(f"http://localhost:{PORT}/json/version", timeout=1) as r:
                break
        except Exception:
            await asyncio.sleep(0.5)
            
    req = urllib.request.Request(f"http://localhost:{PORT}/json/new?http://localhost:8080/index.html", method="PUT")
    with urllib.request.urlopen(req) as r:
        target = json.loads(r.read().decode())
    ws_url = target.get("webSocketDebuggerUrl")

    async with websockets.connect(ws_url) as ws:
        async def evaluate(expr):
            m = {"id": 1, "method": "Runtime.evaluate", "params": {"expression": expr, "awaitPromise": True, "returnByValue": True}}
            await ws.send(json.dumps(m))
            while True:
                resp = json.loads(await ws.recv())
                if resp.get("id") == 1:
                    return resp.get("result", {}).get("result", {}).get("value")

        await asyncio.sleep(1.0)
        # Test importing dist/index.js
        test_script = """
        (async () => {
            const mod = await import('./dist/index.js');
            return {
                hasModuleAuth: typeof mod.AuthService !== 'undefined',
                hasModuleStorage: typeof mod.StorageService !== 'undefined',
                hasModuleCalc: typeof mod.CalculatorService !== 'undefined',
                hasWindowEzia: typeof window.Ezia !== 'undefined',
                bmiCalc: mod.CalculatorService.calculateBMI(70, 175),
                guestLogin: mod.AuthService.loginAsGuest()
            };
        })()
        """
        res = await evaluate(test_script)
        print("BROWSER_FACADE_TEST_RESULT:", json.dumps(res, indent=2))

    proc.kill()

if __name__ == "__main__":
    asyncio.run(test_facade())
