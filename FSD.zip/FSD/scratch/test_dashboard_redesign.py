import asyncio, base64, json, os, subprocess, time, urllib.request
import websockets

CHROME_PATH = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
PORT = 9227
USER_DATA = r"C:\temp\chrome_dashboard_redesign_profile"
ARTIFACT_DIR = r"C:\Users\kalwa\.gemini\antigravity\brain\bf2a4ac8-a660-4c32-afc2-0ec0609314ce"

async def test_dashboard():
    cmd = [
        CHROME_PATH,
        f"--remote-debugging-port={PORT}",
        f"--user-data-dir={USER_DATA}",
        "--headless=new",
        "--disable-gpu",
        "--window-size=1280,950",
        "--no-first-run",
        "--no-default-browser-check"
    ]
    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    for _ in range(20):
        try:
            with urllib.request.urlopen(f"http://localhost:{PORT}/json/version", timeout=1) as r:
                break
        except Exception:
            await asyncio.sleep(0.5)

    req = urllib.request.Request(f"http://localhost:{PORT}/json/new?http://localhost:8080/dashboard.html", method="PUT")
    with urllib.request.urlopen(req) as r:
        target = json.loads(r.read().decode())

    console_errors = []
    network_errors = []

    async with websockets.connect(target.get("webSocketDebuggerUrl")) as ws:
        msg_id = 1
        async def send(method, params=None):
            nonlocal msg_id
            m = {"id": msg_id, "method": method, "params": params or {}}
            msg_id += 1
            await ws.send(json.dumps(m))
            return m["id"]

        async def wait_for_resp(req_id):
            while True:
                msg = await ws.recv()
                data = json.loads(msg)
                if data.get("id") == req_id:
                    return data

        await send("Page.enable")
        await send("Runtime.enable")
        await send("Network.enable")
        await send("Page.navigate", {"url": "http://localhost:8080/dashboard.html"})

        start_time = time.time()
        while time.time() - start_time < 3:
            try:
                msg = await asyncio.wait_for(ws.recv(), timeout=0.5)
                data = json.loads(msg)
                if data.get("method") == "Runtime.consoleAPICalled":
                    if data["params"]["type"] == "error":
                        console_errors.append(data["params"]["args"])
                elif data.get("method") == "Network.responseReceived":
                    status = data["params"]["response"]["status"]
                    if status >= 400:
                        network_errors.append(f"{status} on {data['params']['response']['url']}")
            except asyncio.TimeoutError:
                pass

        # Evaluate Greeting and Bento Elements
        eval_id = await send("Runtime.evaluate", {
            "expression": """
                ({
                    greeting: document.getElementById('greetingHeading')?.textContent,
                    scoreVal: document.getElementById('wellnessScoreVal')?.textContent,
                    summary: document.getElementById('wellnessSummary')?.textContent,
                    waterVal: document.getElementById('metricWaterVal')?.textContent,
                    hasQuickBtn: !!document.getElementById('quickLogWaterBtn')
                })
            """,
            "returnByValue": True
        })
        eval_res = await wait_for_resp(eval_id)
        print("DOM State:", eval_res.get("result", {}).get("value"))

        # Test Quick Log Water Click
        click_id = await send("Runtime.evaluate", {
            "expression": """
                (() => {
                    const btn = document.getElementById('quickLogWaterBtn');
                    if (btn) btn.click();
                    return document.getElementById('metricWaterVal')?.textContent;
                })()
            """,
            "returnByValue": True
        })
        click_res = await wait_for_resp(click_id)
        print("After +250ml quick-add waterVal:", click_res.get("result", {}).get("value"))

        await asyncio.sleep(0.5)

        # Take screenshot
        shot_id = await send("Page.captureScreenshot", {"format": "png"})
        shot_res = await wait_for_resp(shot_id)
        img_bytes = base64.b64decode(shot_res["result"]["data"])
        out_path = os.path.join(ARTIFACT_DIR, "redesigned_dashboard_screenshot.png")
        with open(out_path, "wb") as f:
            f.write(img_bytes)
        print(f"Captured redesigned dashboard screenshot ({len(img_bytes)} bytes) at {out_path}")

    proc.terminate()
    print("Console errors:", console_errors)
    print("Network errors:", network_errors)

if __name__ == "__main__":
    asyncio.run(test_dashboard())
