import asyncio, base64, json, os, subprocess, time, urllib.request
import websockets

CHROME_PATH = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
PORT = 9228
USER_DATA = r"C:\temp\chrome_redesign_screenshots_profile"
ARTIFACT_DIR = r"C:\Users\kalwa\.gemini\antigravity\brain\bf2a4ac8-a660-4c32-afc2-0ec0609314ce"

async def capture_all_redesigned():
    cmd = [
        CHROME_PATH,
        f"--remote-debugging-port={PORT}",
        f"--user-data-dir={USER_DATA}",
        "--headless=new",
        "--disable-gpu",
        "--window-size=1280,950",
        "--no-first-run",
        "--no-default-browser-check"
    ]
    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    for _ in range(25):
        try:
            with urllib.request.urlopen(f"http://localhost:{PORT}/json/version", timeout=1) as r:
                break
        except Exception:
            await asyncio.sleep(0.5)

    pages = [
        ("dashboard.html", "redesigned_dashboard_screenshot.png"),
        ("hydration.html", "redesigned_hydration_screenshot.png"),
        ("sleep.html", "redesigned_sleep_screenshot.png")
    ]

    results = {}

    for page_file, shot_name in pages:
        page_url = f"http://localhost:8080/{page_file}"
        print(f"\n--- AUDITING {page_file} ---")

        req = urllib.request.Request(f"http://localhost:{PORT}/json/new?{page_url}", method="PUT")
        with urllib.request.urlopen(req) as r:
            target = json.loads(r.read().decode())

        console_errors = []
        network_errors = []

        async with websockets.connect(target.get("webSocketDebuggerUrl")) as ws:
            msg_id = 1
            async def send(method, params=None):
                nonlocal msg_id
                m = {"id": msg_id, "method": method, "params": params or {}}
                msg_id += 1
                await ws.send(json.dumps(m))
                return m["id"]

            async def wait_for_resp(req_id):
                while True:
                    msg = await ws.recv()
                    data = json.loads(msg)
                    if data.get("id") == req_id:
                        return data

            await send("Page.enable")
            await send("Runtime.enable")
            await send("Network.enable")
            await send("Page.navigate", {"url": page_url})

            start_time = time.time()
            while time.time() - start_time < 3:
                try:
                    msg = await asyncio.wait_for(ws.recv(), timeout=0.5)
                    data = json.loads(msg)
                    if data.get("method") == "Runtime.consoleAPICalled":
                        if data["params"]["type"] == "error":
                            console_errors.append(data["params"]["args"])
                    elif data.get("method") == "Network.responseReceived":
                        status = data["params"]["response"]["status"]
                        if status >= 400:
                            network_errors.append(f"{status} on {data['params']['response']['url']}")
                except asyncio.TimeoutError:
                    pass

            # Page-specific interactions
            if page_file == "hydration.html":
                # Click the +500 ml preset button
                await send("Runtime.evaluate", {
                    "expression": """
                        (() => {
                            const btn = document.querySelector('.quick-btn[data-ml="500"]');
                            if (btn) btn.click();
                        })()
                    """
                })
                await asyncio.sleep(0.5)
            elif page_file == "sleep.html":
                # Select a 5-star rating
                await send("Runtime.evaluate", {
                    "expression": """
                        (() => {
                            const btn = document.querySelector('.star-btn[data-rating="5"]');
                            if (btn) btn.click();
                        })()
                    """
                })
                await asyncio.sleep(0.5)

            # Capture screenshot
            shot_id = await send("Page.captureScreenshot", {"format": "png"})
            shot_res = await wait_for_resp(shot_id)
            img_bytes = base64.b64decode(shot_res["result"]["data"])
            out_path = os.path.join(ARTIFACT_DIR, shot_name)
            with open(out_path, "wb") as f:
                f.write(img_bytes)
            print(f"Captured {shot_name} ({len(img_bytes)} bytes) at {out_path}")

            results[page_file] = {
                "console_errors": len(console_errors),
                "network_errors": len(network_errors),
                "screenshot": shot_name
            }

    proc.terminate()
    print("\n--- AUDIT SUMMARY ---")
    for page, res in results.items():
        print(f"{page}: {res['console_errors']} console errors, {res['network_errors']} network errors -> {res['screenshot']}")

if __name__ == "__main__":
    asyncio.run(capture_all_redesigned())
