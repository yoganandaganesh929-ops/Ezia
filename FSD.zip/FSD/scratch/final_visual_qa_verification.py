import asyncio, base64, json, os, subprocess, time, urllib.request
import websockets

CHROME_PATH = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
PORT = 9229
USER_DATA = r"C:\temp\chrome_final_qa_verification_profile"
ARTIFACT_DIR = r"C:\Users\kalwa\.gemini\antigravity\brain\bf2a4ac8-a660-4c32-afc2-0ec0609314ce"

async def run_final_qa():
    cmd = [
        CHROME_PATH,
        f"--remote-debugging-port={PORT}",
        f"--user-data-dir={USER_DATA}",
        "--headless=new",
        "--disable-gpu",
        "--window-size=1440,900",
        "--no-first-run",
        "--no-default-browser-check"
    ]
    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    for _ in range(25):
        try:
            with urllib.request.urlopen(f"http://localhost:{PORT}/json/version", timeout=1) as r:
                break
        except Exception:
            await asyncio.sleep(0.5)

    pages = [
        ("index.html", "qa_desktop_landing.png"),
        ("login.html", "qa_desktop_login.png"),
        ("register.html", "qa_desktop_register.png"),
        ("dashboard.html", "qa_desktop_dashboard.png"),
        ("calculator.html", "qa_desktop_calculator.png"),
        ("hydration.html", "qa_desktop_hydration.png"),
        ("sleep.html", "qa_desktop_sleep.png"),
        ("insights.html", "qa_desktop_insights.png"),
        ("history.html", "qa_desktop_history.png"),
        ("settings.html", "qa_desktop_settings.png")
    ]

    desktop_results = {}
    responsive_results = {}
    functional_results = {}
    accessibility_results = {}

    print("==================================================")
    print("STEP 1: DESKTOP SCREENSHOTS & AUDIT (1440x900)")
    print("==================================================")

    for page_file, shot_name in pages:
        page_url = f"http://localhost:8080/{page_file}"
        req = urllib.request.Request(f"http://localhost:{PORT}/json/new?{page_url}", method="PUT")
        with urllib.request.urlopen(req) as r:
            target = json.loads(r.read().decode())

        console_errors = []
        network_errors = []

        async with websockets.connect(target.get("webSocketDebuggerUrl")) as ws:
            msg_id = 1
            async def send(method, params=None):
                nonlocal msg_id
                m = {"id": msg_id, "method": method, "params": params or {}}
                msg_id += 1
                await ws.send(json.dumps(m))
                return m["id"]

            async def wait_for_resp(req_id):
                while True:
                    msg = await ws.recv()
                    data = json.loads(msg)
                    if data.get("id") == req_id:
                        return data

            await send("Page.enable")
            await send("Runtime.enable")
            await send("Network.enable")
            await send("Emulation.setDeviceMetricsOverride", {
                "width": 1440,
                "height": 900,
                "deviceScaleFactor": 1,
                "mobile": False
            })
            await send("Page.navigate", {"url": page_url})

            start_time = time.time()
            while time.time() - start_time < 2.5:
                try:
                    msg = await asyncio.wait_for(ws.recv(), timeout=0.4)
                    data = json.loads(msg)
                    if data.get("method") == "Runtime.consoleAPICalled":
                        if data["params"]["type"] == "error":
                            console_errors.append(data["params"]["args"])
                    elif data.get("method") == "Network.responseReceived":
                        status = data["params"]["response"]["status"]
                        if status >= 400:
                            network_errors.append(f"{status} on {data['params']['response']['url']}")
                except asyncio.TimeoutError:
                    pass

            # Accessibility check
            a11y_id = await send("Runtime.evaluate", {
                "expression": """
                    ({
                        imagesWithoutAlt: Array.from(document.querySelectorAll('img:not([alt])')).length,
                        buttonsWithoutLabel: Array.from(document.querySelectorAll('button:not([aria-label]):not([title])')).filter(b => !b.textContent.trim()).length,
                        inputsWithoutLabel: Array.from(document.querySelectorAll('input:not([aria-label]):not([aria-labelledby])')).filter(i => {
                            const id = i.id;
                            return !id || !document.querySelector(`label[for="${id}"]`);
                        }).length
                    })
                """,
                "returnByValue": True
            })
            a11y_res = await wait_for_resp(a11y_id)
            accessibility_results[page_file] = a11y_res.get("result", {}).get("result", {}).get("value")

            # Capture desktop screenshot
            shot_id = await send("Page.captureScreenshot", {"format": "png"})
            shot_res = await wait_for_resp(shot_id)
            img_bytes = base64.b64decode(shot_res["result"]["data"])
            out_path = os.path.join(ARTIFACT_DIR, shot_name)
            with open(out_path, "wb") as f:
                f.write(img_bytes)
            print(f"Captured {shot_name} ({len(img_bytes)} bytes)")

            desktop_results[page_file] = {
                "console_errors": len(console_errors),
                "network_errors": len(network_errors),
                "screenshot": shot_name
            }

    print("\n==================================================")
    print("STEP 2: RESPONSIVE OVERFLOW & MOBILE AUDIT")
    print("==================================================")

    viewports = [
        {"name": "1440x900", "w": 1440, "h": 900, "mobile": False},
        {"name": "1280x800", "w": 1280, "h": 800, "mobile": False},
        {"name": "768x1024", "w": 768, "h": 1024, "mobile": True},
        {"name": "390x844", "w": 390, "h": 844, "mobile": True},
        {"name": "360x800", "w": 360, "h": 800, "mobile": True}
    ]

    overflow_check_pages = ["index.html", "dashboard.html", "hydration.html", "sleep.html", "calculator.html"]

    for vp in viewports:
        print(f"\nTesting Viewport {vp['name']}...")
        vp_overflows = {}
        for p in overflow_check_pages:
            p_url = f"http://localhost:8080/{p}"
            req = urllib.request.Request(f"http://localhost:{PORT}/json/new?{p_url}", method="PUT")
            with urllib.request.urlopen(req) as r:
                tgt = json.loads(r.read().decode())

            async with websockets.connect(tgt.get("webSocketDebuggerUrl")) as ws:
                msg_id = 1
                async def send(method, params=None):
                    nonlocal msg_id
                    m = {"id": msg_id, "method": method, "params": params or {}}
                    msg_id += 1
                    await ws.send(json.dumps(m))
                    return m["id"]

                async def wait_for_resp(req_id):
                    while True:
                        msg = await ws.recv()
                        data = json.loads(msg)
                        if data.get("id") == req_id:
                            return data

                await send("Page.enable")
                await send("Runtime.enable")
                await send("Emulation.setDeviceMetricsOverride", {
                    "width": vp["w"],
                    "height": vp["h"],
                    "deviceScaleFactor": 2 if vp["mobile"] else 1,
                    "mobile": vp["mobile"]
                })
                await send("Page.navigate", {"url": p_url})
                await asyncio.sleep(1.5)

                check_id = await send("Runtime.evaluate", {
                    "expression": """
                        ({
                            scrollWidth: document.documentElement.scrollWidth,
                            clientWidth: document.documentElement.clientWidth,
                            hasHorizontalOverflow: document.documentElement.scrollWidth > document.documentElement.clientWidth
                        })
                    """,
                    "returnByValue": True
                })
                c_res = await wait_for_resp(check_id)
                val = c_res.get("result", {}).get("result", {}).get("value", {})
                vp_overflows[p] = val

                # Capture mobile screenshots at 390x844
                if vp["name"] == "390x844":
                    if p == "dashboard.html":
                        s_id = await send("Page.captureScreenshot", {"format": "png"})
                        s_res = await wait_for_resp(s_id)
                        with open(os.path.join(ARTIFACT_DIR, "qa_mobile_dashboard.png"), "wb") as f:
                            f.write(base64.b64decode(s_res["result"]["data"]))
                        print("Captured qa_mobile_dashboard.png")
                    elif p == "hydration.html":
                        s_id = await send("Page.captureScreenshot", {"format": "png"})
                        s_res = await wait_for_resp(s_id)
                        with open(os.path.join(ARTIFACT_DIR, "qa_mobile_hydration.png"), "wb") as f:
                            f.write(base64.b64decode(s_res["result"]["data"]))
                        print("Captured qa_mobile_hydration.png")
                    elif p == "sleep.html":
                        s_id = await send("Page.captureScreenshot", {"format": "png"})
                        s_res = await wait_for_resp(s_id)
                        with open(os.path.join(ARTIFACT_DIR, "qa_mobile_sleep.png"), "wb") as f:
                            f.write(base64.b64decode(s_res["result"]["data"]))
                        print("Captured qa_mobile_sleep.png")

        responsive_results[vp["name"]] = vp_overflows

    print("\n==================================================")
    print("STEP 3: END-TO-END FUNCTIONAL WORKFLOWS AUDIT")
    print("==================================================")

    # Test Registration & Login
    req_auth = urllib.request.Request(f"http://localhost:{PORT}/json/new?http://localhost:8080/register.html", method="PUT")
    with urllib.request.urlopen(req_auth) as r:
        tgt_auth = json.loads(r.read().decode())

    async with websockets.connect(tgt_auth.get("webSocketDebuggerUrl")) as ws:
        msg_id = 1
        async def send(method, params=None):
            nonlocal msg_id
            m = {"id": msg_id, "method": method, "params": params or {}}
            msg_id += 1
            await ws.send(json.dumps(m))
            return m["id"]

        async def wait_for_resp(req_id):
            while True:
                msg = await ws.recv()
                data = json.loads(msg)
                if data.get("id") == req_id:
                    return data

        await send("Page.enable")
        await send("Runtime.enable")
        await asyncio.sleep(1)

        # Register a QA user
        reg_id = await send("Runtime.evaluate", {
            "expression": """
                (() => {
                    const name = document.getElementById('regName');
                    const email = document.getElementById('regEmail');
                    const pass = document.getElementById('regPassword');
                    const terms = document.getElementById('regTerms');
                    const form = document.getElementById('registerForm');
                    
                    if (name) name.value = 'Dr. Julian Thorne';
                    if (email) email.value = 'julian.thorne@healthhub.org';
                    if (pass) pass.value = 'SanctuaryPass2026!';
                    if (terms) terms.checked = true;
                    
                    form.dispatchEvent(new Event('submit', { cancelable: true }));
                    return { registered: true };
                })()
            """,
            "returnByValue": True
        })
        reg_res = await wait_for_resp(reg_id)
        functional_results["registration"] = reg_res.get("result", {}).get("result", {}).get("value")

    # Verify Dashboard State with registered user
    req_dash = urllib.request.Request(f"http://localhost:{PORT}/json/new?http://localhost:8080/dashboard.html", method="PUT")
    with urllib.request.urlopen(req_dash) as r:
        tgt_dash = json.loads(r.read().decode())

    async with websockets.connect(tgt_dash.get("webSocketDebuggerUrl")) as ws:
        msg_id = 1
        async def send(method, params=None):
            nonlocal msg_id
            m = {"id": msg_id, "method": method, "params": params or {}}
            msg_id += 1
            await ws.send(json.dumps(m))
            return m["id"]

        async def wait_for_resp(req_id):
            while True:
                msg = await ws.recv()
                data = json.loads(msg)
                if data.get("id") == req_id:
                    return data

        await send("Page.enable")
        await send("Runtime.enable")
        await asyncio.sleep(1)

        dash_check = await send("Runtime.evaluate", {
            "expression": """
                (() => {
                    const greeting = document.getElementById('greetingHeading')?.textContent;
                    const quickBtn = document.getElementById('quickLogWaterBtn');
                    if (quickBtn) quickBtn.click();
                    const updatedWater = document.getElementById('metricWaterVal')?.textContent;
                    return {
                        greeting,
                        updatedWater
                    };
                })()
            """,
            "returnByValue": True
        })
        d_res = await wait_for_resp(dash_check)
        functional_results["dashboard"] = d_res.get("result", {}).get("result", {}).get("value")

    # Verify Hydration Custom Logging & Undo
    req_hyd = urllib.request.Request(f"http://localhost:{PORT}/json/new?http://localhost:8080/hydration.html", method="PUT")
    with urllib.request.urlopen(req_hyd) as r:
        tgt_hyd = json.loads(r.read().decode())

    async with websockets.connect(tgt_hyd.get("webSocketDebuggerUrl")) as ws:
        msg_id = 1
        async def send(method, params=None):
            nonlocal msg_id
            m = {"id": msg_id, "method": method, "params": params or {}}
            msg_id += 1
            await ws.send(json.dumps(m))
            return m["id"]

        async def wait_for_resp(req_id):
            while True:
                msg = await ws.recv()
                data = json.loads(msg)
                if data.get("id") == req_id:
                    return data

        await send("Page.enable")
        await send("Runtime.enable")
        await asyncio.sleep(1)

        hyd_check = await send("Runtime.evaluate", {
            "expression": """
                (() => {
                    const customInp = document.getElementById('customAmountInput');
                    const customForm = document.getElementById('customWaterForm');
                    if (customInp) customInp.value = '350';
                    if (customForm) customForm.dispatchEvent(new Event('submit', { cancelable: true }));
                    
                    const afterCustom = document.getElementById('totalWaterText')?.textContent;
                    const undoBtn = document.getElementById('undoLastWaterBtn');
                    if (undoBtn) undoBtn.click();
                    const afterUndo = document.getElementById('totalWaterText')?.textContent;

                    return {
                        afterCustom,
                        afterUndo
                    };
                })()
            """,
            "returnByValue": True
        })
        h_res = await wait_for_resp(hyd_check)
        functional_results["hydration"] = h_res.get("result", {}).get("result", {}).get("value")

    # Verify Sleep Midnight Crossing
    req_slp = urllib.request.Request(f"http://localhost:{PORT}/json/new?http://localhost:8080/sleep.html", method="PUT")
    with urllib.request.urlopen(req_slp) as r:
        tgt_slp = json.loads(r.read().decode())

    async with websockets.connect(tgt_slp.get("webSocketDebuggerUrl")) as ws:
        msg_id = 1
        async def send(method, params=None):
            nonlocal msg_id
            m = {"id": msg_id, "method": method, "params": params or {}}
            msg_id += 1
            await ws.send(json.dumps(m))
            return m["id"]

        async def wait_for_resp(req_id):
            while True:
                msg = await ws.recv()
                data = json.loads(msg)
                if data.get("id") == req_id:
                    return data

        await send("Page.enable")
        await send("Runtime.enable")
        await asyncio.sleep(1)

        slp_check = await send("Runtime.evaluate", {
            "expression": """
                (() => {
                    const bed = document.getElementById('bedtimeInput');
                    const wake = document.getElementById('wakeTimeInput');
                    const form = document.getElementById('sleepForm');
                    if (bed) { bed.value = '22:15'; bed.dispatchEvent(new Event('input')); }
                    if (wake) { wake.value = '06:45'; wake.dispatchEvent(new Event('input')); }
                    const durationBadge = document.getElementById('calculatedDurationBadge')?.textContent;
                    if (form) form.dispatchEvent(new Event('submit', { cancelable: true }));
                    const heroDur = document.getElementById('heroSleepDuration')?.textContent;
                    return {
                        durationBadge,
                        heroDur
                    };
                })()
            """,
            "returnByValue": True
        })
        s_res = await wait_for_resp(slp_check)
        functional_results["sleep"] = s_res.get("result", {}).get("result", {}).get("value")

    # Verify Calculator Teen Safeguard
    req_calc = urllib.request.Request(f"http://localhost:{PORT}/json/new?http://localhost:8080/calculator.html", method="PUT")
    with urllib.request.urlopen(req_calc) as r:
        tgt_calc = json.loads(r.read().decode())

    async with websockets.connect(tgt_calc.get("webSocketDebuggerUrl")) as ws:
        msg_id = 1
        async def send(method, params=None):
            nonlocal msg_id
            m = {"id": msg_id, "method": method, "params": params or {}}
            msg_id += 1
            await ws.send(json.dumps(m))
            return m["id"]

        async def wait_for_resp(req_id):
            while True:
                msg = await ws.recv()
                data = json.loads(msg)
                if data.get("id") == req_id:
                    return data

        await send("Page.enable")
        await send("Runtime.enable")
        await asyncio.sleep(1)

        calc_check = await send("Runtime.evaluate", {
            "expression": """
                (() => {
                    const h = document.getElementById('heightCmInput');
                    const w = document.getElementById('weightKgInput');
                    const a = document.getElementById('ageInput');
                    const form = document.getElementById('calcForm');
                    
                    if (h) h.value = '165';
                    if (w) w.value = '55';
                    if (a) a.value = '15'; // Teen minor
                    if (form) form.dispatchEvent(new Event('submit', { cancelable: true }));

                    const bmrVal = document.getElementById('resultBmrNum')?.textContent;
                    const catBadge = document.getElementById('resultCategoryBadge')?.textContent;
                    const warningDisplay = document.getElementById('pediatricWarningBanner')?.style.display;

                    return {
                        bmrVal,
                        catBadge,
                        warningDisplay
                    };
                })()
            """,
            "returnByValue": True
        })
        c_res = await wait_for_resp(calc_check)
        functional_results["calculator_teen_safeguard"] = c_res.get("result", {}).get("result", {}).get("value")

    proc.terminate()

    print("\n==================================================")
    print("FINAL QUALITY AUDIT SUMMARY")
    print("==================================================")
    print("DESKTOP 10-PAGE AUDIT:")
    for k, v in desktop_results.items():
        print(f"  {k}: {v['console_errors']} console errs, {v['network_errors']} network errs -> {v['screenshot']}")

    print("\nRESPONSIVE OVERFLOW AUDIT:")
    for vp, results in responsive_results.items():
        print(f"  Viewport {vp}:")
        for pg, of in results.items():
            status = "PASS (No overflow)" if not of.get("hasHorizontalOverflow") else f"FAIL ({of['scrollWidth']} > {of['clientWidth']})"
            print(f"    {pg}: {status}")

    print("\nFUNCTIONAL WORKFLOW AUDIT:")
    print(" ", json.dumps(functional_results, indent=2))

    print("\nACCESSIBILITY SEMANTICS AUDIT:")
    print(" ", json.dumps(accessibility_results, indent=2))

if __name__ == "__main__":
    asyncio.run(run_final_qa())
