/**
 * Storage and Export Data Contracts
 */

import { UserProfile, AuthenticatedUser } from './user.js';
import { HydrationLog, SleepLog, BodyMetricEntry } from './health.js';
import { UserSettings } from './settings.js';

export interface ExportPayload {
  schemaVersion: string;
  exportedAt: string;
  user: AuthenticatedUser | null;
  profile: UserProfile;
  hydrationLogs: HydrationLog[];
  sleepLogs: SleepLog[];
  bodyMetrics: BodyMetricEntry[];
  settings: UserSettings;
}
