/**
 * User and Authentication Type Definitions for Ezia
 */

export type UnitPreference = 'metric' | 'imperial';
export type Gender = 'female' | 'male' | 'other' | 'prefer-not-to-say';

export interface UserProfile {
  name: string;
  email: string;
  age: number;
  gender: Gender;
  heightCm: number | null;
  weightKg: number | null;
  unitPreference: UnitPreference;
  waterGoalMl: number;
  sleepGoalHrs: number;
}

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  passwordSalt: string;
  passwordHash: string;
  createdAt: string;
  profile: UserProfile;
}

export interface AuthenticatedUser {
  id: string;
  name: string;
  email: string;
  isGuest?: boolean;
}

export interface UserSession {
  isLoggedIn: boolean;
  token: string;
  user: AuthenticatedUser | null;
  loginTime: string;
  expiresAt: number;
}

export interface RegistrationData {
  name: string;
  email: string;
  password: string;
  age?: number;
  gender?: Gender;
  unitPreference?: UnitPreference;
}

export interface AuthResult {
  success: boolean;
  user?: AuthenticatedUser;
  error?: string;
}
