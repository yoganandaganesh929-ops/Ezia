/**
 * Health, Anthropometric, and Wellness Measurement Type Definitions
 */

export interface HydrationLog {
  id: string;
  date: string;       // YYYY-MM-DD
  time: string;       // HH:MM
  amountMl: number;
  timestamp: number;
}

export type SleepRating = 1 | 2 | 3 | 4 | 5;

export interface SleepLog {
  id: string;
  date: string;       // YYYY-MM-DD
  bedtime: string;    // HH:MM
  wakeTime: string;   // HH:MM
  durationHours: number;
  restfulness: SleepRating;
  notes: string;
  timestamp: number;
}

export interface BodyMetricEntry {
  id: string;
  date: string;       // YYYY-MM-DD
  weightKg: number;
  heightCm: number;
  bmi: number;
  bmr: number | null; // Null for minors under pediatric safeguard
  age: number;
  gender: string;
  timestamp: number;
}

export interface BMICategory {
  category: string;
  badgeClass: 'badge-mint' | 'badge-amber' | 'badge-error' | 'badge-navy';
  summary: string;
  isAdultCutoff?: boolean;
}

export interface WellnessScoreComponents {
  hydration: number;   // Max 40
  sleep: number;       // Max 40
  consistency: number; // Max 20
}

export interface DailyWellnessScore {
  hasData: boolean;
  totalScore: number;  // 0 - 100
  components: WellnessScoreComponents;
  hydrationLoggedMl: number;
  hydrationGoalMl: number;
  sleepLoggedHours: number;
}

export interface WeeklyTrendDay {
  dayName: string;
  date: string;
  waterMl: number;
  sleepHrs: number;
  wellnessScore: number;
}
