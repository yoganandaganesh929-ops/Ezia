/**
 * Application Preferences and Configuration Types
 */

import { UnitPreference } from './user.js';

export type ThemeMode = 'light' | 'dark' | 'system';

export interface UserSettings {
  unit: UnitPreference;
  remindersEnabled: boolean;
  theme: ThemeMode;
  soundEnabled: boolean;
}
