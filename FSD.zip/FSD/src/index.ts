/**
 * Master Application Entrypoint & Backward-Compatible Facade
 * Exposes both modern modular ES classes and legacy window.Ezia API.
 */

import { AuthService } from './services/auth.service.js';
import { StorageService } from './services/storage.service.js';
import { CalculatorService } from './services/calculator.service.js';
import { CryptoService } from './services/crypto.service.js';
import { Toast } from './ui/toast.js';
import { SidebarController } from './ui/sidebar.js';
import { DateBadge } from './ui/date-badge.js';
import { ThemeController } from './ui/theme.js';
import { eventBus } from './core/events.js';
import { CONFIG } from './core/config.js';

// Export modern modular architecture
export {
  AuthService,
  StorageService,
  CalculatorService,
  CryptoService,
  Toast,
  SidebarController,
  DateBadge,
  ThemeController,
  eventBus,
  CONFIG
};

// Backward-compatible global facade for existing scripts & automated tests
const legacyPublicApi = {
  Auth: {
    getSession: () => AuthService.getSession(),
    isAuthenticated: () => AuthService.isAuthenticated(),
    getCurrentUser: () => AuthService.getCurrentUser(),
    register: (data: any) => AuthService.register(data),
    login: (e: string, p: string) => AuthService.login(e, p),
    logout: () => AuthService.logout(),
    loginAsGuest: () => AuthService.loginAsGuest(),
    ensureSession: () => AuthService.ensureSession(),
    deleteAccount: () => AuthService.deleteAccount()
  },
  Storage: {
    getActiveUserId: () => StorageService.getActiveUserId(),
    getProfile: () => StorageService.getProfile(),
    saveProfile: (p: any) => StorageService.saveProfile(p),
    getHydrationLogs: () => StorageService.getHydrationLogs(),
    addHydrationEntry: (ml: number) => StorageService.addHydrationEntry(ml),
    deleteHydrationEntry: (id: string) => StorageService.deleteHydrationEntry(id),
    getSleepLogs: () => StorageService.getSleepLogs(),
    addSleepEntry: (s: any) => StorageService.addSleepEntry(s),
    deleteSleepEntry: (id: string) => StorageService.deleteSleepEntry(id),
    getBodyMetrics: () => StorageService.getBodyMetrics(),
    saveBodyMetricEntry: (m: any) => StorageService.saveBodyMetricEntry(m),
    getSettings: () => StorageService.getSettings(),
    saveSettings: (s: any) => StorageService.saveSettings(s),
    exportAllJSON: () => StorageService.exportAllJSON(),
    clearUserData: (u: string) => StorageService.clearUserData(u),
    resetUserLogs: () => StorageService.resetUserLogs()
  },
  Calc: {
    calculateBMI: (w: number, h: number) => CalculatorService.calculateBMI(w, h),
    getBMICategory: (b: number, a?: number) => CalculatorService.getBMICategory(b, a),
    calculateBMR: (w: number, h: number, a: number, g?: string) => CalculatorService.calculateBMR(w, h, a, g),
    calculateSleepDuration: (b: string, w: string) => CalculatorService.calculateSleepDuration(b, w),
    calculateDailyWellnessScore: (d?: string) => CalculatorService.calculateDailyWellnessScore(d),
    kgToLbs: (kg: number) => CalculatorService.kgToLbs(kg),
    lbsToKg: (lbs: number) => CalculatorService.lbsToKg(lbs),
    cmToFtIn: (cm: number) => CalculatorService.cmToFtIn(cm),
    ftInToCm: (ft: number, inc: number) => CalculatorService.ftInToCm(ft, inc),
    mlToOz: (ml: number) => CalculatorService.mlToOz(ml),
    ozToMl: (oz: number) => CalculatorService.ozToMl(oz)
  },
  Crypto: {
    generateSalt: () => CryptoService.generateSalt(),
    hashPassword: (p: string, s: string) => CryptoService.hashPassword(p, s),
    generateSessionToken: () => CryptoService.generateSessionToken()
  },
  BACKEND_CONFIG: {
    configured: false,
    mode: 'client-secure',
    endpointUrl: null,
    apiVersion: 'v1'
  },
  showToast: (m: string, t: any) => Toast.show(m, t),
  initMobileSidebar: () => SidebarController.init(),
  requireAuth: () => AuthService.ensureSession()
};

if (typeof window !== 'undefined') {
  (window as any).Ezia = legacyPublicApi;
}

if (typeof globalThis !== 'undefined') {
  (globalThis as any).Ezia = legacyPublicApi;
}
