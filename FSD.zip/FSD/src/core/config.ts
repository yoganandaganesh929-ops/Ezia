/**
 * Centralized Application Configuration & Constants
 */

export const CONFIG = {
  APP_NAME: 'Ezia',
  APP_VERSION: '2.0.0',
  SCHEMA_VERSION: '2.0',
  
  // Storage keys (aligned with existing keys for zero-data-loss migration)
  STORAGE_KEYS: {
    ACCOUNTS: 'ezia_accounts_v2',
    ACTIVE_SESSION: 'ezia_session_v2',
    LEGACY_PREFIX: 'ezia_u_'
  },

  // Security & Authentication
  AUTH: {
    SESSION_DURATION_MS: 7 * 24 * 60 * 60 * 1000, // 7 days
    GUEST_SESSION_DURATION_MS: 365 * 24 * 60 * 60 * 1000, // 1 year
    MIN_PASSWORD_LENGTH: 8,
    GUEST_USER_ID: 'guest_user',
    GUEST_USER_EMAIL: 'guest@ezia.local',
    GUEST_USER_NAME: 'Guest Explorer'
  },

  // Health Science & Safety
  CLINICAL_BOUNDS: {
    MIN_ADULT_AGE: 18,
    DEFAULT_WATER_GOAL_ML: 2500,
    DEFAULT_SLEEP_GOAL_HRS: 8.0,
    MAX_WATER_LOG_ENTRY_ML: 5000,
    MAX_SLEEP_HOURS: 24.0
  },

  // UI & Design System
  UI: {
    TOAST_DURATION_MS: 3200,
    ANIMATION_DURATION_MS: 250
  }
} as const;
