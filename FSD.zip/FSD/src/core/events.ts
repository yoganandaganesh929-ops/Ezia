/**
 * Strongly Typed Event Bus for Reactive State & UI Synchronisation
 */

export type AppEventMap = {
  'auth:login': { userId: string; isGuest: boolean };
  'auth:logout': void;
  'hydration:added': { amountMl: number; totalMl: number };
  'hydration:deleted': { id: string };
  'sleep:added': { durationHours: number };
  'sleep:deleted': { id: string };
  'metrics:saved': { bmi: number; bmr: number | null };
  'profile:updated': void;
  'settings:updated': void;
};

type EventHandler<T> = (payload: T) => void;

class TypedEventBus {
  private listeners: Map<keyof AppEventMap, Set<EventHandler<any>>> = new Map();

  public on<K extends keyof AppEventMap>(event: K, handler: EventHandler<AppEventMap[K]>): () => void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(handler);

    // Return unbind function
    return () => this.off(event, handler);
  }

  public off<K extends keyof AppEventMap>(event: K, handler: EventHandler<AppEventMap[K]>): void {
    const handlers = this.listeners.get(event);
    if (handlers) {
      handlers.delete(handler);
    }
  }

  public emit<K extends keyof AppEventMap>(
    event: K,
    ...args: AppEventMap[K] extends void ? [] : [AppEventMap[K]]
  ): void {
    const handlers = this.listeners.get(event);
    if (handlers) {
      const payload = args[0];
      handlers.forEach(handler => {
        try {
          handler(payload);
        } catch (err) {
          console.error(`Error in event handler for ${String(event)}:`, err);
        }
      });
    }
  }
}

export const eventBus = new TypedEventBus();
