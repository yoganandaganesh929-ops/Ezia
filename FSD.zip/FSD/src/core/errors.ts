/**
 * Centralized Typed Error Handling & Validation
 */

export class AppError extends Error {
  constructor(message: string, public readonly code: string = 'APP_ERROR') {
    super(message);
    this.name = 'AppError';
  }
}

export class ValidationError extends AppError {
  constructor(message: string, public readonly field?: string) {
    super(message, 'VALIDATION_ERROR');
    this.name = 'ValidationError';
  }
}

export class AuthError extends AppError {
  constructor(message: string) {
    super(message, 'AUTH_ERROR');
    this.name = 'AuthError';
  }
}

export class StorageError extends AppError {
  constructor(message: string) {
    super(message, 'STORAGE_ERROR');
    this.name = 'StorageError';
  }
}

export class ErrorHandler {
  public static handle(error: unknown, fallbackMessage: string = 'An unexpected error occurred'): string {
    if (error instanceof AppError) {
      console.warn(`[${error.name}] (${error.code}): ${error.message}`);
      return error.message;
    }
    if (error instanceof Error) {
      console.error('[UnhandledError]:', error);
      return error.message || fallbackMessage;
    }
    console.error('[UnknownError]:', error);
    return fallbackMessage;
  }
}
