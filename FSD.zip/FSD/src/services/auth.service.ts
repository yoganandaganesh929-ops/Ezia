/**
 * Genuine Authentication Service with Web Crypto SHA-256 Hashing & Guest Sandbox
 */

import { CONFIG } from '../core/config.js';
import { AuthError, ValidationError } from '../core/errors.js';
import { CryptoService } from './crypto.service.js';
import { StorageService } from './storage.service.js';
import { AuthenticatedUser, AuthResult, RegistrationData, UserAccount, UserSession } from '../types/user.js';
import { eventBus } from '../core/events.js';

export class AuthService {
  public static getSession(): UserSession | null {
    return StorageService.getSession();
  }

  public static isAuthenticated(): boolean {
    const session = this.getSession();
    return !!(session && session.isLoggedIn && session.user);
  }

  public static getCurrentUser(): AuthenticatedUser | null {
    const session = this.getSession();
    return session ? session.user : null;
  }

  /**
   * Registers a new account with salted SHA-256 password encryption
   */
  public static async register(data: RegistrationData): Promise<AuthResult> {
    const normalizedEmail = (data.email || '').trim().toLowerCase();
    const name = (data.name || '').trim();
    const password = data.password || '';

    if (!normalizedEmail || !name || !password) {
      return { success: false, error: 'Full name, email address, and password are required.' };
    }

    if (password.length < CONFIG.AUTH.MIN_PASSWORD_LENGTH) {
      return { success: false, error: `Password must be at least ${CONFIG.AUTH.MIN_PASSWORD_LENGTH} characters in length.` };
    }

    const accounts = StorageService.getAccounts();
    if (accounts[normalizedEmail]) {
      return { success: false, error: 'An account with this email address already exists. Please sign in.' };
    }

    const salt = CryptoService.generateSalt();
    const passwordHash = await CryptoService.hashPassword(password, salt);
    const userId = `usr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

    const newAccount: UserAccount = {
      id: userId,
      name,
      email: normalizedEmail,
      passwordSalt: salt,
      passwordHash,
      createdAt: new Date().toISOString(),
      profile: {
        name,
        email: normalizedEmail,
        age: Number(data.age) || 28,
        gender: data.gender || 'female',
        heightCm: null,
        weightKg: null,
        unitPreference: data.unitPreference || 'metric',
        waterGoalMl: CONFIG.CLINICAL_BOUNDS.DEFAULT_WATER_GOAL_ML,
        sleepGoalHrs: CONFIG.CLINICAL_BOUNDS.DEFAULT_SLEEP_GOAL_HRS
      }
    };

    accounts[normalizedEmail] = newAccount;
    StorageService.saveAccounts(accounts);

    const user: AuthenticatedUser = {
      id: userId,
      name: newAccount.name,
      email: normalizedEmail,
      isGuest: false
    };

    const session: UserSession = {
      isLoggedIn: true,
      token: CryptoService.generateSessionToken(),
      user,
      loginTime: new Date().toISOString(),
      expiresAt: Date.now() + CONFIG.AUTH.SESSION_DURATION_MS
    };

    StorageService.saveSession(session);
    eventBus.emit('auth:login', { userId, isGuest: false });

    return { success: true, user };
  }

  /**
   * Authenticates user credentials against the salted SHA-256 hash
   */
  public static async login(email: string, password: string): Promise<AuthResult> {
    const normalizedEmail = (email || '').trim().toLowerCase();
    if (!normalizedEmail || !password) {
      return { success: false, error: 'Please enter both your email address and password.' };
    }

    const accounts = StorageService.getAccounts();
    const account = accounts[normalizedEmail];
    if (!account) {
      return { success: false, error: 'No account found with this email. Please create an account first.' };
    }

    const candidateHash = await CryptoService.hashPassword(password, account.passwordSalt);
    if (candidateHash !== account.passwordHash) {
      return { success: false, error: 'Incorrect password. Please verify your credentials.' };
    }

    const user: AuthenticatedUser = {
      id: account.id,
      name: account.name,
      email: account.email,
      isGuest: false
    };

    const session: UserSession = {
      isLoggedIn: true,
      token: CryptoService.generateSessionToken(),
      user,
      loginTime: new Date().toISOString(),
      expiresAt: Date.now() + CONFIG.AUTH.SESSION_DURATION_MS
    };

    StorageService.saveSession(session);
    eventBus.emit('auth:login', { userId: user.id, isGuest: false });

    return { success: true, user };
  }

  /**
   * Instant Guest Mode access without credentials or signup friction
   */
  public static loginAsGuest(): AuthResult {
    const existing = this.getSession();
    if (existing && existing.isLoggedIn && existing.user) {
      return { success: true, user: existing.user };
    }

    const guestUser: AuthenticatedUser = {
      id: CONFIG.AUTH.GUEST_USER_ID,
      name: CONFIG.AUTH.GUEST_USER_NAME,
      email: CONFIG.AUTH.GUEST_USER_EMAIL,
      isGuest: true
    };

    const guestSession: UserSession = {
      isLoggedIn: true,
      user: guestUser,
      token: `guest_${Date.now()}`,
      loginTime: new Date().toISOString(),
      expiresAt: Date.now() + CONFIG.AUTH.GUEST_SESSION_DURATION_MS
    };

    StorageService.saveSession(guestSession);
    eventBus.emit('auth:login', { userId: guestUser.id, isGuest: true });

    return { success: true, user: guestUser };
  }

  public static logout(): void {
    StorageService.clearSession();
    eventBus.emit('auth:logout');
  }

  public static ensureSession(): AuthenticatedUser {
    if (!this.isAuthenticated()) {
      this.loginAsGuest();
    }
    return this.getCurrentUser()!;
  }

  public static deleteAccount(): boolean {
    const session = this.getSession();
    if (!session || !session.user) return false;

    const email = session.user.email;
    const userId = session.user.id;

    const accounts = StorageService.getAccounts();
    delete accounts[email];
    StorageService.saveAccounts(accounts);

    StorageService.clearUserData(userId);
    this.logout();
    return true;
  }
}
