/**
 * Cryptographic Utilities: Web Crypto API SHA-256 Hashing, Salt, & Session Tokens
 */

export class CryptoService {
  /**
   * Generates a secure random 32-character hexadecimal salt (16 bytes)
   */
  public static generateSalt(): string {
    const arr = new Uint8Array(16);
    if (typeof window !== 'undefined' && window.crypto && window.crypto.getRandomValues) {
      window.crypto.getRandomValues(arr);
    } else if (typeof globalThis !== 'undefined' && globalThis.crypto && globalThis.crypto.getRandomValues) {
      globalThis.crypto.getRandomValues(arr);
    } else {
      for (let i = 0; i < 16; i++) arr[i] = Math.floor(Math.random() * 256);
    }
    return Array.from(arr).map(b => b.toString(16).padStart(2, '0')).join('');
  }

  /**
   * Cryptographically hashes password with salt using Web Crypto SHA-256
   */
  public static async hashPassword(password: string, salt: string): Promise<string> {
    const cryptoApi = (typeof window !== 'undefined' ? window.crypto : null) ||
                      (typeof globalThis !== 'undefined' ? globalThis.crypto : null);

    if (!cryptoApi || !cryptoApi.subtle) {
      // Deterministic fallback for environments without subtle crypto
      let hash = 0;
      const combined = `${salt}:${password}`;
      for (let i = 0; i < combined.length; i++) {
        const char = combined.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash |= 0;
      }
      return 'fb_' + Math.abs(hash).toString(16);
    }

    const enc = new TextEncoder();
    const data = enc.encode(`${salt}:${password}`);
    const digestBuffer = await cryptoApi.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(digestBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  /**
   * Generates secure 48-character hexadecimal random session token (24 bytes)
   */
  public static generateSessionToken(): string {
    const arr = new Uint8Array(24);
    const cryptoApi = (typeof window !== 'undefined' ? window.crypto : null) ||
                      (typeof globalThis !== 'undefined' ? globalThis.crypto : null);

    if (cryptoApi && cryptoApi.getRandomValues) {
      cryptoApi.getRandomValues(arr);
    } else {
      for (let i = 0; i < 24; i++) arr[i] = Math.floor(Math.random() * 256);
    }
    return Array.from(arr).map(b => b.toString(16).padStart(2, '0')).join('');
  }
}
