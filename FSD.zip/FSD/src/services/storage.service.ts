/**
 * Strongly Typed Storage Service with User Isolation & Safe Defaults
 */

import { CONFIG } from '../core/config.js';
import { StorageError } from '../core/errors.js';
import { UserAccount, UserProfile, UserSession } from '../types/user.js';
import { HydrationLog, SleepLog, BodyMetricEntry } from '../types/health.js';
import { UserSettings } from '../types/settings.js';
import { ExportPayload } from '../types/storage.js';

export interface IStorageAdapter {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

class BrowserLocalStorageAdapter implements IStorageAdapter {
  getItem(key: string): string | null {
    try {
      if (typeof localStorage !== 'undefined') {
        return localStorage.getItem(key);
      }
    } catch (e) {
      console.warn('LocalStorage read error:', e);
    }
    return null;
  }

  setItem(key: string, value: string): void {
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(key, value);
      }
    } catch (e) {
      console.error('LocalStorage write error:', e);
      throw new StorageError('Browser storage quota exceeded or storage unavailable.');
    }
  }

  removeItem(key: string): void {
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.removeItem(key);
      }
    } catch (e) {
      console.warn('LocalStorage remove error:', e);
    }
  }
}

export class StorageService {
  private static adapter: IStorageAdapter = new BrowserLocalStorageAdapter();

  public static setAdapter(customAdapter: IStorageAdapter): void {
    this.adapter = customAdapter;
  }

  public static getActiveUserId(): string {
    const session = this.getSession();
    return (session && session.user && session.user.id) ? session.user.id : CONFIG.AUTH.GUEST_USER_ID;
  }

  private static getUserKey(feature: string): string {
    const uid = this.getActiveUserId();
    return `${CONFIG.STORAGE_KEYS.LEGACY_PREFIX}${uid}_${feature}_v2`;
  }

  // --- Accounts Registry ---
  public static getAccounts(): Record<string, UserAccount> {
    try {
      const raw = this.adapter.getItem(CONFIG.STORAGE_KEYS.ACCOUNTS);
      return raw ? JSON.parse(raw) : {};
    } catch (e) {
      return {};
    }
  }

  public static saveAccounts(accounts: Record<string, UserAccount>): void {
    this.adapter.setItem(CONFIG.STORAGE_KEYS.ACCOUNTS, JSON.stringify(accounts));
  }

  // --- Active Session ---
  public static getSession(): UserSession | null {
    try {
      const raw = this.adapter.getItem(CONFIG.STORAGE_KEYS.ACTIVE_SESSION);
      if (!raw) return null;
      const session: UserSession = JSON.parse(raw);
      if (session.expiresAt && Date.now() > session.expiresAt) {
        this.clearSession();
        return null;
      }
      return session;
    } catch (e) {
      return null;
    }
  }

  public static saveSession(session: UserSession): void {
    this.adapter.setItem(CONFIG.STORAGE_KEYS.ACTIVE_SESSION, JSON.stringify(session));
  }

  public static clearSession(): void {
    this.adapter.removeItem(CONFIG.STORAGE_KEYS.ACTIVE_SESSION);
  }

  // --- User Profile ---
  public static getProfile(): UserProfile {
    const uid = this.getActiveUserId();
    const session = this.getSession();
    const accounts = this.getAccounts();

    if (session && session.user && accounts[session.user.email]) {
      const acc = accounts[session.user.email];
      return {
        ...acc.profile,
        name: acc.name,
        email: acc.email
      };
    }

    try {
      const raw = this.adapter.getItem(this.getUserKey('profile'));
      if (raw) return JSON.parse(raw);
    } catch (e) {}

    return {
      name: session && session.user ? session.user.name : '',
      email: session && session.user ? session.user.email : '',
      age: 28,
      gender: 'female',
      heightCm: null,
      weightKg: null,
      unitPreference: 'metric',
      waterGoalMl: CONFIG.CLINICAL_BOUNDS.DEFAULT_WATER_GOAL_ML,
      sleepGoalHrs: CONFIG.CLINICAL_BOUNDS.DEFAULT_SLEEP_GOAL_HRS
    };
  }

  public static saveProfile(profile: Partial<UserProfile>): UserProfile {
    const current = this.getProfile();
    const updated: UserProfile = {
      ...current,
      ...profile,
      age: profile.age !== undefined ? Number(profile.age) : current.age,
      waterGoalMl: profile.waterGoalMl !== undefined ? Number(profile.waterGoalMl) : current.waterGoalMl,
      sleepGoalHrs: profile.sleepGoalHrs !== undefined ? Number(profile.sleepGoalHrs) : current.sleepGoalHrs
    };

    const session = this.getSession();
    const accounts = this.getAccounts();
    if (session && session.user && accounts[session.user.email]) {
      const acc = accounts[session.user.email];
      if (updated.name) acc.name = updated.name;
      acc.profile = updated;
      this.saveAccounts(accounts);
    }

    this.adapter.setItem(this.getUserKey('profile'), JSON.stringify(updated));
    return updated;
  }

  // --- Hydration Entries ---
  public static getHydrationLogs(): HydrationLog[] {
    try {
      const raw = this.adapter.getItem(this.getUserKey('hydration'));
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }

  public static addHydrationEntry(amountMl: number): HydrationLog {
    const logs = this.getHydrationLogs();
    const now = new Date();
    const entry: HydrationLog = {
      id: `h_${Date.now()}`,
      date: now.toISOString().split('T')[0],
      time: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      amountMl: Math.round(Number(amountMl)),
      timestamp: now.getTime()
    };
    logs.unshift(entry);
    this.adapter.setItem(this.getUserKey('hydration'), JSON.stringify(logs));
    return entry;
  }

  public static deleteHydrationEntry(id: string): void {
    let logs = this.getHydrationLogs();
    logs = logs.filter(item => item.id !== id);
    this.adapter.setItem(this.getUserKey('hydration'), JSON.stringify(logs));
  }

  // --- Sleep Entries ---
  public static getSleepLogs(): SleepLog[] {
    try {
      const raw = this.adapter.getItem(this.getUserKey('sleep'));
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }

  public static addSleepEntry(entry: Omit<SleepLog, 'id' | 'timestamp'>): SleepLog {
    const logs = this.getSleepLogs();
    const now = new Date();
    const newLog: SleepLog = {
      ...entry,
      id: `s_${Date.now()}`,
      timestamp: now.getTime(),
      notes: (entry.notes || '').trim()
    };
    logs.unshift(newLog);
    this.adapter.setItem(this.getUserKey('sleep'), JSON.stringify(logs));
    return newLog;
  }

  public static deleteSleepEntry(id: string): void {
    let logs = this.getSleepLogs();
    logs = logs.filter(item => item.id !== id);
    this.adapter.setItem(this.getUserKey('sleep'), JSON.stringify(logs));
  }

  // --- Body Metrics History ---
  public static getBodyMetrics(): BodyMetricEntry[] {
    try {
      const raw = this.adapter.getItem(this.getUserKey('metrics'));
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }

  public static saveBodyMetricEntry(entry: Omit<BodyMetricEntry, 'id' | 'timestamp'>): BodyMetricEntry {
    const history = this.getBodyMetrics();
    const newEntry: BodyMetricEntry = {
      ...entry,
      id: `bm_${Date.now()}`,
      timestamp: Date.now()
    };
    history.unshift(newEntry);
    this.adapter.setItem(this.getUserKey('metrics'), JSON.stringify(history));

    // Synchronize baseline profile
    this.saveProfile({
      weightKg: newEntry.weightKg,
      heightCm: newEntry.heightCm,
      age: newEntry.age,
      gender: newEntry.gender as any
    });

    return newEntry;
  }

  // --- Settings ---
  public static getSettings(): UserSettings {
    try {
      const raw = this.adapter.getItem(this.getUserKey('settings'));
      if (raw) return JSON.parse(raw);
    } catch (e) {}

    return {
      unit: 'metric',
      remindersEnabled: false,
      theme: 'light',
      soundEnabled: true
    };
  }

  public static saveSettings(settings: Partial<UserSettings>): UserSettings {
    const current = this.getSettings();
    const updated: UserSettings = { ...current, ...settings };
    this.adapter.setItem(this.getUserKey('settings'), JSON.stringify(updated));
    return updated;
  }

  // --- User Data Erasure & Export ---
  public static clearUserData(userId: string): void {
    const features = ['profile', 'hydration', 'sleep', 'metrics', 'settings'];
    features.forEach(f => this.adapter.removeItem(`${CONFIG.STORAGE_KEYS.LEGACY_PREFIX}${userId}_${f}_v2`));
  }

  public static resetUserLogs(): void {
    const uid = this.getActiveUserId();
    this.clearUserData(uid);
  }

  public static exportAllJSON(): string {
    const session = this.getSession();
    const payload: ExportPayload = {
      schemaVersion: CONFIG.SCHEMA_VERSION,
      exportedAt: new Date().toISOString(),
      user: session ? session.user : null,
      profile: this.getProfile(),
      hydrationLogs: this.getHydrationLogs(),
      sleepLogs: this.getSleepLogs(),
      bodyMetrics: this.getBodyMetrics(),
      settings: this.getSettings()
    };
    return JSON.stringify(payload, null, 2);
  }
}
