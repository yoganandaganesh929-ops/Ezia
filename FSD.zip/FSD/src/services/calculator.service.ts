/**
 * Evidence-Based Scientific Calculation Models with Pediatric Minor Safeguards
 */

import { CONFIG } from '../core/config.js';
import { BMICategory, DailyWellnessScore } from '../types/health.js';
import { StorageService } from './storage.service.js';

export class CalculatorService {
  /**
   * Body Mass Index: weight (kg) / (height (m))^2
   */
  public static calculateBMI(weightKg: number, heightCm: number): number {
    if (!weightKg || !heightCm || heightCm <= 0) return 0;
    const heightM = heightCm / 100;
    const bmi = weightKg / (heightM * heightM);
    return Number(bmi.toFixed(1));
  }

  /**
   * Clinical Adult BMI Categories with strict Minor Safeguard (WHO & CDC)
   */
  public static getBMICategory(bmi: number, age: number = 25): BMICategory {
    if (!bmi || bmi <= 0) {
      return {
        category: 'Awaiting Measurements',
        badgeClass: 'badge-navy',
        summary: 'Enter your stature and mass to compute standard population reference ratio.'
      };
    }

    // Pediatric Safeguard: Adult cutoffs are biologically invalid for growing bodies
    if (age < CONFIG.CLINICAL_BOUNDS.MIN_ADULT_AGE) {
      return {
        category: 'Pediatric Reference (Growth Charts)',
        badgeClass: 'badge-amber',
        summary: 'Adult BMI cutoff categories do not apply to minors. Interpretation requires age-and-sex percentile growth charts with a pediatrician.',
        isAdultCutoff: false
      };
    }

    if (bmi < 18.5) {
      return {
        category: 'Underweight Range (< 18.5)',
        badgeClass: 'badge-amber',
        summary: 'Below standard reference weight range. Discuss nutritional balance and energy intake with your doctor.',
        isAdultCutoff: true
      };
    } else if (bmi < 25.0) {
      return {
        category: 'Standard Range (18.5 – 24.9)',
        badgeClass: 'badge-mint',
        summary: 'Within typical adult population reference weight range.',
        isAdultCutoff: true
      };
    } else if (bmi < 30.0) {
      return {
        category: 'Elevated Range (25.0 – 29.9)',
        badgeClass: 'badge-amber',
        summary: 'Above standard reference threshold. Focus on whole-food nourishment and regular movement without extreme caloric restriction.',
        isAdultCutoff: true
      };
    } else {
      return {
        category: 'High Reference Range (30.0+)',
        badgeClass: 'badge-error',
        summary: 'Above standard population reference threshold. Consult a licensed physician for personalized health assessment.',
        isAdultCutoff: true
      };
    }
  }

  /**
   * Basal Metabolic Rate using Mifflin-St Jeor formula (adults only)
   * Strictly returns null for minors under 18.
   */
  public static calculateBMR(weightKg: number, heightCm: number, age: number, gender: string = 'female'): number | null {
    if (!weightKg || !heightCm || !age) return 0;
    if (age < CONFIG.CLINICAL_BOUNDS.MIN_ADULT_AGE) return null;

    let bmr = (10 * weightKg) + (6.25 * heightCm) - (5 * age);
    if (gender.toLowerCase() === 'male') {
      bmr += 5;
    } else {
      bmr -= 161;
    }
    return Math.round(bmr);
  }

  /**
   * Accurate sleep duration supporting midnight crossover
   */
  public static calculateSleepDuration(bedtimeStr: string, wakeTimeStr: string): number {
    if (!bedtimeStr || !wakeTimeStr) return 0;
    const [bHour, bMin] = bedtimeStr.split(':').map(Number);
    const [wHour, wMin] = wakeTimeStr.split(':').map(Number);

    if (isNaN(bHour) || isNaN(bMin) || isNaN(wHour) || isNaN(wMin)) return 0;

    let bMinutes = bHour * 60 + bMin;
    let wMinutes = wHour * 60 + wMin;

    if (wMinutes < bMinutes) {
      // Midnight crossover (e.g. 23:15 to 07:15)
      wMinutes += 24 * 60;
    }
    const totalMinutes = wMinutes - bMinutes;
    return Number((totalMinutes / 60).toFixed(1));
  }

  /**
   * Authentic Clinical Daily Wellness Score (0 to 100)
   * Zero fabricated numbers: score is only awarded for real recorded inputs.
   */
  public static calculateDailyWellnessScore(dateStr?: string): DailyWellnessScore {
    const targetDate = dateStr || new Date().toISOString().split('T')[0];
    const profile = StorageService.getProfile();

    const hydLogs = StorageService.getHydrationLogs().filter(item => item.date === targetDate);
    const sleepLogs = StorageService.getSleepLogs().filter(item => item.date === targetDate);

    const totalWater = hydLogs.reduce((sum, item) => sum + item.amountMl, 0);
    const waterGoal = profile.waterGoalMl || CONFIG.CLINICAL_BOUNDS.DEFAULT_WATER_GOAL_ML;

    // 1. Hydration Component (Max 40 points)
    const hydRatio = Math.min(1, totalWater / waterGoal);
    const hydrationScore = Math.round(hydRatio * 40);

    // 2. Sleep Component (Max 40 points)
    let sleepScore = 0;
    let sleepLoggedHours = 0;
    if (sleepLogs.length > 0) {
      const latestSleep = sleepLogs[0];
      sleepLoggedHours = latestSleep.durationHours;
      const sleepGoal = profile.sleepGoalHrs || CONFIG.CLINICAL_BOUNDS.DEFAULT_SLEEP_GOAL_HRS;
      const durationRatio = Math.min(1, latestSleep.durationHours / sleepGoal);
      const qualityRatio = latestSleep.restfulness / 5;
      sleepScore = Math.round((durationRatio * 0.7 + qualityRatio * 0.3) * 40);
    }

    // 3. Consistency Component (Max 20 points)
    let consistencyScore = 0;
    if (hydLogs.length > 0) consistencyScore += 10;
    if (sleepLogs.length > 0) consistencyScore += 10;

    const totalScore = Math.min(100, hydrationScore + sleepScore + consistencyScore);
    const hasAnyData = (hydLogs.length > 0 || sleepLogs.length > 0);

    return {
      hasData: hasAnyData,
      totalScore,
      components: {
        hydration: hydrationScore,
        sleep: sleepScore,
        consistency: consistencyScore
      },
      hydrationLoggedMl: totalWater,
      hydrationGoalMl: waterGoal,
      sleepLoggedHours
    };
  }

  // --- Anthropometric and Liquid Unit Conversions ---
  public static kgToLbs(kg: number): number {
    return Number((kg * 2.20462).toFixed(1));
  }

  public static lbsToKg(lbs: number): number {
    return Number((lbs / 2.20462).toFixed(1));
  }

  public static cmToFtIn(cm: number): { feet: number; inches: number } {
    const totalInches = cm / 2.54;
    const feet = Math.floor(totalInches / 12);
    const inches = Math.round(totalInches % 12);
    return { feet, inches };
  }

  public static ftInToCm(feet: number, inches: number): number {
    return Math.round((Number(feet) * 30.48) + (Number(inches) * 2.54));
  }

  public static mlToOz(ml: number): number {
    return Number((ml * 0.033814).toFixed(1));
  }

  public static ozToMl(oz: number): number {
    return Math.round(oz / 0.033814);
  }
}
