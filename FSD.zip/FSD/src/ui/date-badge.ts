/**
 * Header Date Formatter
 */

export class DateBadge {
  public static init(elementId: string = 'headerDateBadge'): void {
    const el = document.getElementById(elementId);
    if (el) {
      el.textContent = new Date().toLocaleDateString([], {
        weekday: 'short',
        month: 'short',
        day: 'numeric'
      });
      el.style.visibility = 'visible';
    }
  }
}
