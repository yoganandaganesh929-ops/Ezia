/**
 * Accessible Status Toast Notifications
 */

import { CONFIG } from '../core/config.js';

export type ToastType = 'info' | 'success' | 'warning' | 'error';

export class Toast {
  private static getContainer(): HTMLElement {
    let container = document.getElementById('toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toast-container';
      container.setAttribute('aria-live', 'polite');
      container.setAttribute('aria-atomic', 'true');
      document.body.appendChild(container);
    }
    return container;
  }

  public static show(message: string, type: ToastType = 'info'): void {
    if (typeof document === 'undefined') return;

    const container = this.getContainer();
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.setAttribute('role', type === 'error' ? 'alert' : 'status');

    // Accessible iconography
    const iconSpan = document.createElement('span');
    iconSpan.className = 'toast-icon';
    if (type === 'success') iconSpan.textContent = '✓';
    else if (type === 'error') iconSpan.textContent = '✕';
    else if (type === 'warning') iconSpan.textContent = '⚠';
    else iconSpan.textContent = 'ℹ';

    const textSpan = document.createElement('span');
    textSpan.className = 'toast-text';
    textSpan.textContent = message;

    toast.appendChild(iconSpan);
    toast.appendChild(textSpan);
    container.appendChild(toast);

    // Dismissal timer
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = `all ${CONFIG.UI.ANIMATION_DURATION_MS}ms ease`;
      setTimeout(() => toast.remove(), CONFIG.UI.ANIMATION_DURATION_MS);
    }, CONFIG.UI.TOAST_DURATION_MS);
  }

  public static success(message: string): void {
    this.show(message, 'success');
  }

  public static error(message: string): void {
    this.show(message, 'error');
  }

  public static info(message: string): void {
    this.show(message, 'info');
  }

  public static warning(message: string): void {
    this.show(message, 'warning');
  }
}
