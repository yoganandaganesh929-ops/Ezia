/**
 * Theme & Color Preference Controller
 */

import { StorageService } from '../services/storage.service.js';
import { ThemeMode } from '../types/settings.js';

export class ThemeController {
  public static init(): void {
    const settings = StorageService.getSettings();
    this.applyTheme(settings.theme || 'light');
  }

  public static applyTheme(theme: ThemeMode): void {
    if (typeof document === 'undefined') return;

    if (theme === 'system') {
      const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
      document.documentElement.setAttribute('data-theme', prefersDark ? 'dark' : 'light');
    } else {
      document.documentElement.setAttribute('data-theme', theme);
    }
  }

  public static setTheme(theme: ThemeMode): void {
    StorageService.saveSettings({ theme });
    this.applyTheme(theme);
  }
}
