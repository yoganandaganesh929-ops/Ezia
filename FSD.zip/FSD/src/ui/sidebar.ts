/**
 * Reusable Navigation Sidebar Controller & Shell Initializer
 * Replaces redundant copy-pasted sidebar code across all authenticated pages.
 */

import { AuthService } from '../services/auth.service.js';
import { StorageService } from '../services/storage.service.js';

export class SidebarController {
  public static init(): void {
    if (typeof document === 'undefined') return;

    // Ensure session (defaults seamlessly to Guest Mode)
    AuthService.ensureSession();

    const user = AuthService.getCurrentUser();
    const profile = StorageService.getProfile();
    const isGuest = user && user.isGuest;

    const activeName = (user && user.name) || profile.name || (isGuest ? 'Guest Explorer' : 'Member');

    // 1. Sidebar User Name
    const nameEl = document.getElementById('sidebarUserName');
    if (nameEl) {
      nameEl.textContent = activeName;
    }

    // 2. Avatar Initials
    const avatarEl = document.getElementById('sidebarAvatar');
    if (avatarEl) {
      const initials = isGuest ? 'GE' : (activeName
        .split(' ')
        .filter(Boolean)
        .map(part => part[0])
        .slice(0, 2)
        .join('')
        .toUpperCase() || 'EZ');
      avatarEl.textContent = initials;
      avatarEl.style.visibility = 'visible';
    }

    const userInfoEl = document.getElementById('sidebarUserInfo');
    if (userInfoEl) {
      userInfoEl.style.visibility = 'visible';
    }

    // 3. User Session Status Label
    const statusEl = document.getElementById('sidebarUserStatus');
    if (statusEl) {
      statusEl.textContent = isGuest ? 'Guest Session' : 'Private Session';
    }

    // 4. Logout / Sign In Link
    const logoutLink = document.getElementById('sidebarLogout') as HTMLAnchorElement | null;
    if (logoutLink) {
      if (isGuest) {
        logoutLink.textContent = 'Sign In / Register →';
      }
      logoutLink.addEventListener('click', (e) => {
        e.preventDefault();
        if (!isGuest) {
          AuthService.logout();
        }
        window.location.href = './login.html';
      });
    }

    // 5. Mobile Drawer Toggle & Backdrop
    const toggleBtn = document.getElementById('mobileSidebarToggle');
    const sidebar = document.querySelector('.sidebar');
    const backdrop = document.querySelector('.sidebar-backdrop');

    if (toggleBtn && sidebar) {
      toggleBtn.addEventListener('click', () => {
        sidebar.classList.toggle('is-open');
        if (backdrop) backdrop.classList.toggle('is-active');
      });
    }

    if (backdrop && sidebar) {
      backdrop.addEventListener('click', () => {
        sidebar.classList.remove('is-open');
        backdrop.classList.remove('is-active');
      });
    }

    // 6. Highlight Active Navigation Item Based on Location
    this.highlightActiveNavItem();
  }

  private static highlightActiveNavItem(): void {
    const rawPath = window.location.pathname;
    let fileName = rawPath.split('/').pop() || 'dashboard.html';
    if (!fileName || fileName === '') fileName = 'dashboard.html';
    if (!fileName.includes('.')) fileName += '.html';

    const navLinks = document.querySelectorAll<HTMLAnchorElement>('.sidebar-nav a');
    navLinks.forEach(link => {
      const href = (link.getAttribute('href') || '').replace('./', '').split('?')[0].split('#')[0];
      if (href && (href === fileName || rawPath.endsWith(href))) {
        link.classList.add('active');
        link.setAttribute('aria-current', 'page');
      } else {
        link.classList.remove('active');
        link.removeAttribute('aria-current');
      }
    });
  }
}
