/**
 * Verification of Modern TypeScript Output against All Health, Auth & Storage Assertions
 */

import {
  AuthService,
  StorageService,
  CalculatorService,
  CryptoService
} from '../index.js';

class MockLocalStorage {
  private store: Record<string, string> = {};
  getItem(key: string): string | null {
    return this.store[key] || null;
  }
  setItem(key: string, value: string): void {
    this.store[key] = String(value);
  }
  removeItem(key: string): void {
    delete this.store[key];
  }
  clear(): void {
    this.store = {};
  }
}

const mockStorage = new MockLocalStorage();
StorageService.setAdapter(mockStorage);

let passedCount = 0;
let failedCount = 0;

function assert(condition: boolean, message: string) {
  if (condition) {
    console.log(`  [PASS] ${message}`);
    passedCount++;
  } else {
    console.error(`  [FAIL] ${message}`);
    failedCount++;
  }
}

export async function runModernTestSuite() {
  console.log('================================================================');
  console.log('EZIA MODERN TYPESCRIPT ARCHITECTURE VERIFICATION TEST SUITE');
  console.log('================================================================\n');

  // TEST 1: Zero Demo Seeding Verification
  console.log('TEST 1: Zero Demo Seeding Verification');
  assert(mockStorage.getItem('ezia_hydration_logs') === null, 'No global demo hydration logs in storage');
  assert(mockStorage.getItem('ezia_sleep_logs') === null, 'No global demo sleep logs in storage');

  // TEST 2: Web Crypto Salted Password Hashing
  console.log('\nTEST 2: Web Crypto Salted Password Hashing');
  const salt = CryptoService.generateSalt();
  assert(Boolean(salt && salt.length === 32), 'Cryptographic salt generated with 32 hex characters');
  const hash1 = await CryptoService.hashPassword('MySecurePassword123!', salt);
  const hash2 = await CryptoService.hashPassword('MySecurePassword123!', salt);
  const hashDiffSalt = await CryptoService.hashPassword('MySecurePassword123!', CryptoService.generateSalt());
  assert(hash1 === hash2, 'Identical password + salt yields deterministic SHA-256 hash');
  assert(hash1 !== hashDiffSalt, 'Different salt yields different hash');
  assert(hash1.length === 64, 'SHA-256 hash output is 64 hex characters');

  // TEST 3: User Registration & Input Validation
  console.log('\nTEST 3: User Registration & Input Validation');
  const reg1 = await AuthService.register({
    name: 'Elena Rostova',
    email: 'elena.rostova@example.com',
    password: 'SecurePassword123!',
    age: 32,
    gender: 'female',
    unitPreference: 'metric'
  });
  assert(reg1.success === true, 'Elena Rostova registered successfully');
  assert(!!(reg1.user && reg1.user.id), 'User assigned unique persistent ID');
  assert(AuthService.isAuthenticated() === true, 'User is authenticated immediately after registration');

  const accounts = StorageService.getAccounts();
  const storedUser = accounts['elena.rostova@example.com'];
  assert(storedUser !== undefined, 'User record exists in ezia_accounts_v2 registry');
  assert((storedUser as any).password === undefined, 'Plaintext password is NEVER stored in database');
  assert(storedUser.passwordHash !== undefined && storedUser.passwordSalt !== undefined, 'Password stored exclusively as salted SHA-256 hash');

  // Duplicate registration rejection
  const regDup = await AuthService.register({
    name: 'Elena Clone',
    email: 'elena.rostova@example.com',
    password: 'DifferentPassword123!',
    age: 30
  });
  assert(regDup.success === false, 'Duplicate email registration is rejected with error: ' + regDup.error);

  // Password < 8 characters rejection
  const shortPassReg = await AuthService.register({
    name: 'Short Pass',
    email: 'short.pass@example.com',
    password: 'short',
    age: 25
  });
  assert(shortPassReg.success === false, 'Password under 8 chars rejected with error: ' + shortPassReg.error);

  // TEST 4: Secure Authentication & Session Handling
  console.log('\nTEST 4: Secure Authentication & Session Handling');
  AuthService.logout();
  assert(AuthService.isAuthenticated() === false, 'User successfully signed out (session cleared)');

  const badLogin = await AuthService.login('elena.rostova@example.com', 'WrongPassword123!');
  assert(badLogin.success === false, 'Incorrect password rejected');
  assert(AuthService.isAuthenticated() === false, 'No session created on failed login');

  const goodLogin = await AuthService.login('elena.rostova@example.com', 'SecurePassword123!');
  assert(goodLogin.success === true, 'Correct credentials authenticate successfully');
  assert(AuthService.isAuthenticated() === true, 'Active session created');
  const currentUser = AuthService.getCurrentUser();
  assert(currentUser?.name === 'Elena Rostova', 'Active session reflects Elena Rostova profile');

  // TEST 5: User-Specific Storage Isolation
  console.log('\nTEST 5: User-Specific Storage Isolation');
  const elenaId = currentUser!.id;
  const elenaHydKey = `ezia_u_${elenaId}_hydration_v2`;

  StorageService.addHydrationEntry(250);
  StorageService.addHydrationEntry(500);
  StorageService.addSleepEntry({
    date: '2026-11-20',
    bedtime: '22:30',
    wakeTime: '06:30',
    durationHours: 8.0,
    restfulness: 4,
    notes: 'Chamomile tea'
  });

  const elenaHydLogs = JSON.parse(mockStorage.getItem(elenaHydKey)!);
  assert(elenaHydLogs && elenaHydLogs.length === 2, `Elena logs isolated in key ${elenaHydKey} (2 entries)`);
  assert(elenaHydLogs[0].amountMl === 500 && elenaHydLogs[1].amountMl === 250, 'Hydration entries in reverse-chronological order');

  // Register second user: Marcus Vance
  const reg2 = await AuthService.register({
    name: 'Marcus Vance',
    email: 'marcus.vance@example.com',
    password: 'MarcusPassword999!',
    age: 40,
    gender: 'male',
    unitPreference: 'imperial'
  });
  assert(reg2.success === true, 'Marcus Vance registered successfully');
  const marcusId = reg2.user!.id;
  assert(marcusId !== elenaId, 'Marcus and Elena have distinct unique user IDs');

  // Marcus logs different water amount
  StorageService.addHydrationEntry(750);
  const marcusHydKey = `ezia_u_${marcusId}_hydration_v2`;
  const marcusHydLogs = JSON.parse(mockStorage.getItem(marcusHydKey)!);
  assert(marcusHydLogs && marcusHydLogs.length === 1 && marcusHydLogs[0].amountMl === 750, 'Marcus has exactly 1 entry of 750 ml in his own isolated storage');

  // Verify Elena's logs were not contaminated
  const elenaHydLogsAfter = JSON.parse(mockStorage.getItem(elenaHydKey)!);
  assert(elenaHydLogsAfter.length === 2, 'Elena storage remains strictly isolated (still 2 entries)');

  // TEST 6: Scientific Health Calculations & Formulas
  console.log('\nTEST 6: Scientific Health Calculations & Formulas');
  const bmiStandard = CalculatorService.calculateBMI(70, 175);
  assert(bmiStandard === 22.9, 'Standard adult BMI calculation accurate: 22.9 (expected 22.9)');

  const catNormal = CalculatorService.getBMICategory(22.9, 30);
  assert(catNormal.badgeClass === 'badge-mint', 'BMI 22.9 classified in Standard Range (badge-mint)');

  const catUnder = CalculatorService.getBMICategory(17.5, 30);
  assert(catUnder.badgeClass === 'badge-amber', 'BMI 17.5 classified in Underweight Range (badge-amber)');

  const catHigh = CalculatorService.getBMICategory(31.2, 30);
  assert(catHigh.badgeClass === 'badge-error', 'BMI 31.2 classified in High Reference Range (badge-error)');

  const bmrMale = CalculatorService.calculateBMR(80, 180, 35, 'male');
  assert(bmrMale === 1755, 'Male Mifflin-St Jeor BMR accurate: 1755 kcal (expected 1755)');

  const bmrFemale = CalculatorService.calculateBMR(60, 165, 28, 'female');
  assert(bmrFemale === 1330, 'Female Mifflin-St Jeor BMR accurate: 1330 kcal (expected 1330)');

  const sleepDuration = CalculatorService.calculateSleepDuration('23:15', '07:45');
  assert(sleepDuration === 8.5, 'Sleep crossing midnight duration accurate: 8.5 hrs (expected 8.5)');

  // TEST 7: Pediatric Minor Safety Safeguards
  console.log('\nTEST 7: Pediatric Minor Safety Safeguards');
  const pediatricBmi = CalculatorService.getBMICategory(21.0, 15);
  assert(pediatricBmi.isAdultCutoff === false, 'Adult BMI cutoffs deactivated for minors (age < 18)');
  assert(pediatricBmi.category.includes('Pediatric Reference'), 'Pediatric reference growth chart notice provided');
  assert(pediatricBmi.badgeClass === 'badge-amber', 'Safety caution badge-amber applied for minors');

  const pediatricBmr = CalculatorService.calculateBMR(55, 160, 15, 'female');
  assert(pediatricBmr === null, 'BMR calculation strictly returns null for minors under 18 (protecting against adult caloric restriction)');

  // TEST 8: Instant Guest Mode (No Credentials / Friction)
  console.log('\nTEST 8: Instant Guest Mode (No Credentials / Friction)');
  AuthService.logout();
  const guestRes = AuthService.loginAsGuest();
  assert(guestRes.success === true, 'Guest mode initialized immediately');
  assert(guestRes.user?.isGuest === true, 'User is marked as Guest');
  assert(guestRes.user?.id === 'guest_user', 'Guest user ID assigned');
  assert(AuthService.isAuthenticated() === true, 'Guest user is authenticated');

  // Guest data isolation
  StorageService.addHydrationEntry(300);
  const guestHydKey = 'ezia_u_guest_user_hydration_v2';
  const guestLogs = JSON.parse(mockStorage.getItem(guestHydKey)!);
  assert(guestLogs && guestLogs.length === 1 && guestLogs[0].amountMl === 300, 'Guest entries isolated in guest namespace');

  // TEST 9: Account Deletion & Data Privacy
  console.log('\nTEST 9: Account Deletion & Data Privacy');
  await AuthService.login('elena.rostova@example.com', 'SecurePassword123!');
  const deleteResult = AuthService.deleteAccount();
  assert(deleteResult === true, 'Account deletion confirmed');
  assert(AuthService.isAuthenticated() === false, 'User logged out after account deletion');
  const accountsAfter = StorageService.getAccounts();
  assert(accountsAfter['elena.rostova@example.com'] === undefined, 'Elena record erased from accounts registry');
  assert(mockStorage.getItem(elenaHydKey) === null, 'Elena isolated hydration logs permanently purged');

  console.log('\n================================================================');
  console.log(`MODERN SUITE SUMMARY: ${passedCount} PASSED, ${failedCount} FAILED`);
  console.log('================================================================');

  if (failedCount > 0) {
    throw new Error('Test suite failed');
  }
}

runModernTestSuite();
