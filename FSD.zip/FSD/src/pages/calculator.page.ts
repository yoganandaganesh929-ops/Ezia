/**
 * Ezia Body Metrics & BMR Clinical Calculator Controller (src/pages/calculator.page.ts)
 * Strongly typed TypeScript controller for anthropometric calculations with strict pediatric safety.
 */

import {
  StorageService,
  CalculatorService,
  SidebarController,
  Toast
} from '../index.js';
import { UnitPreference } from '../types/user.js';
import { BodyMetricEntry } from '../types/health.js';

export class CalculatorPageController {
  private static currentUnit: UnitPreference = 'metric';

  public static init(): void {
    if (typeof document === 'undefined') return;

    // 1. Navigation & Profile
    SidebarController.init();

    const profile = StorageService.getProfile();
    this.currentUnit = profile.unitPreference || 'metric';

    // 2. Unit Toggling Buttons
    const metricBtn = document.getElementById('unitMetricBtn');
    const imperialBtn = document.getElementById('unitImperialBtn');

    if (metricBtn && imperialBtn) {
      metricBtn.addEventListener('click', () => {
        this.syncImperialToMetric();
        this.setUnitMode('metric');
      });

      imperialBtn.addEventListener('click', () => {
        this.syncMetricToImperial();
        this.setUnitMode('imperial');
      });
    }

    // 3. Pre-fill initial values from user profile
    this.populateInitialInputs(profile);
    this.setUnitMode(this.currentUnit);

    // 4. Form Submit
    const form = document.getElementById('calcForm') as HTMLFormElement | null;
    if (form) {
      form.addEventListener('submit', (e: SubmitEvent) => {
        e.preventDefault();
        this.handleCalculation();
      });
    }

    // 5. Initial Render
    this.render();
  }

  private static populateInitialInputs(profile: any): void {
    const heightCmInput = document.getElementById('heightCmInput') as HTMLInputElement | null;
    const weightKgInput = document.getElementById('weightKgInput') as HTMLInputElement | null;
    const ageInput = document.getElementById('ageInput') as HTMLInputElement | null;
    const genderSelect = document.getElementById('genderSelect') as HTMLSelectElement | null;

    if (profile.heightCm && heightCmInput) heightCmInput.value = String(profile.heightCm);
    if (profile.weightKg && weightKgInput) weightKgInput.value = String(profile.weightKg);
    if (profile.age && ageInput) ageInput.value = String(profile.age);
    if (profile.gender && genderSelect) genderSelect.value = profile.gender;

    if (profile.heightCm && profile.weightKg) {
      this.syncMetricToImperial();
    }
  }

  private static setUnitMode(unit: UnitPreference): void {
    this.currentUnit = unit;
    const metricBtn = document.getElementById('unitMetricBtn');
    const imperialBtn = document.getElementById('unitImperialBtn');
    const metricFields = document.getElementById('metricInputFields');
    const imperialFields = document.getElementById('imperialInputFields');

    if (unit === 'metric') {
      metricBtn?.classList.add('active');
      imperialBtn?.classList.remove('active');
      if (metricFields) metricFields.style.display = 'block';
      if (imperialFields) imperialFields.style.display = 'none';
    } else {
      imperialBtn?.classList.add('active');
      metricBtn?.classList.remove('active');
      if (metricFields) metricFields.style.display = 'none';
      if (imperialFields) imperialFields.style.display = 'block';
    }
  }

  private static syncMetricToImperial(): void {
    const heightCmInput = document.getElementById('heightCmInput') as HTMLInputElement | null;
    const weightKgInput = document.getElementById('weightKgInput') as HTMLInputElement | null;
    const heightFtInput = document.getElementById('heightFtInput') as HTMLInputElement | null;
    const heightInInput = document.getElementById('heightInInput') as HTMLInputElement | null;
    const weightLbsInput = document.getElementById('weightLbsInput') as HTMLInputElement | null;

    const cm = parseFloat(heightCmInput?.value || '0');
    const kg = parseFloat(weightKgInput?.value || '0');

    if (cm > 0 && heightFtInput && heightInInput) {
      const { feet, inches } = CalculatorService.cmToFtIn(cm);
      heightFtInput.value = String(feet);
      heightInInput.value = String(inches);
    }

    if (kg > 0 && weightLbsInput) {
      weightLbsInput.value = String(CalculatorService.kgToLbs(kg));
    }
  }

  private static syncImperialToMetric(): void {
    const heightCmInput = document.getElementById('heightCmInput') as HTMLInputElement | null;
    const weightKgInput = document.getElementById('weightKgInput') as HTMLInputElement | null;
    const heightFtInput = document.getElementById('heightFtInput') as HTMLInputElement | null;
    const heightInInput = document.getElementById('heightInInput') as HTMLInputElement | null;
    const weightLbsInput = document.getElementById('weightLbsInput') as HTMLInputElement | null;

    const ft = parseFloat(heightFtInput?.value || '0');
    const inc = parseFloat(heightInInput?.value || '0');
    const lbs = parseFloat(weightLbsInput?.value || '0');

    if (ft > 0 && heightCmInput) {
      heightCmInput.value = String(CalculatorService.ftInToCm(ft, inc));
    }

    if (lbs > 0 && weightKgInput) {
      weightKgInput.value = String(CalculatorService.lbsToKg(lbs));
    }
  }

  private static handleCalculation(): void {
    let heightCm = 0;
    let weightKg = 0;

    const heightCmInput = document.getElementById('heightCmInput') as HTMLInputElement | null;
    const weightKgInput = document.getElementById('weightKgInput') as HTMLInputElement | null;
    const heightFtInput = document.getElementById('heightFtInput') as HTMLInputElement | null;
    const heightInInput = document.getElementById('heightInInput') as HTMLInputElement | null;
    const weightLbsInput = document.getElementById('weightLbsInput') as HTMLInputElement | null;
    const ageInput = document.getElementById('ageInput') as HTMLInputElement | null;
    const genderSelect = document.getElementById('genderSelect') as HTMLSelectElement | null;

    if (this.currentUnit === 'metric') {
      heightCm = parseFloat(heightCmInput?.value || '0');
      weightKg = parseFloat(weightKgInput?.value || '0');
    } else {
      const ft = parseFloat(heightFtInput?.value || '0');
      const inc = parseFloat(heightInInput?.value || '0');
      const lbs = parseFloat(weightLbsInput?.value || '0');
      heightCm = CalculatorService.ftInToCm(ft, inc);
      weightKg = CalculatorService.lbsToKg(lbs);
    }

    const age = parseInt(ageInput?.value || '0', 10);
    const gender = genderSelect?.value || 'female';

    if (isNaN(heightCm) || heightCm < 50 || heightCm > 260) {
      Toast.error('Please enter a realistic height measurement (50 - 260 cm).');
      return;
    }

    if (isNaN(weightKg) || weightKg < 20 || weightKg > 400) {
      Toast.error('Please enter a realistic weight measurement (20 - 400 kg).');
      return;
    }

    if (isNaN(age) || age < 10 || age > 120) {
      Toast.error('Please specify a valid age (10 - 120 years).');
      return;
    }

    // Compute via CalculatorService
    const bmi = CalculatorService.calculateBMI(weightKg, heightCm);
    const bmr = CalculatorService.calculateBMR(weightKg, heightCm, age, gender);
    const todayStr = new Date().toISOString().split('T')[0];

    StorageService.saveBodyMetricEntry({
      date: todayStr,
      weightKg,
      heightCm,
      bmi,
      bmr,
      age,
      gender
    });

    Toast.success(`Calculated BMI: ${bmi}${bmr !== null ? ` · BMR: ${bmr} kcal` : ''}`);
    this.render();
  }

  public static render(): void {
    const metricsLogs = StorageService.getBodyMetrics();
    const resultBmiNum = document.getElementById('resultBmiNum');
    const resultBmrNum = document.getElementById('resultBmrNum');
    const resultCategoryBadge = document.getElementById('resultCategoryBadge');
    const resultCategoryText = document.getElementById('resultCategoryText');
    const needleLabel = document.getElementById('needleLabel');
    const pediatricWarning = document.getElementById('pediatricWarningBanner');
    const tableBody = document.getElementById('metricsHistoryTableBody');

    if (metricsLogs.length > 0) {
      const latest = metricsLogs[0];
      const cat = CalculatorService.getBMICategory(latest.bmi, latest.age);

      if (resultBmiNum) resultBmiNum.textContent = String(latest.bmi);
      if (resultCategoryBadge) {
        resultCategoryBadge.textContent = cat.category;
        resultCategoryBadge.className = `badge ${cat.badgeClass}`;
      }
      if (resultCategoryText) resultCategoryText.textContent = cat.summary;

      // Adult BMR vs Pediatric Guard
      if (resultBmrNum) {
        if (latest.age < 18 || latest.bmr === null) {
          resultBmrNum.textContent = 'Exempt';
        } else {
          resultBmrNum.textContent = latest.bmr.toLocaleString();
        }
      }

      // Pediatric warning banner
      if (pediatricWarning) {
        pediatricWarning.style.display = latest.age < 18 ? 'flex' : 'none';
      }

      if (needleLabel) {
        needleLabel.textContent = `BMI: ${latest.bmi} (${cat.category})`;
      }
    } else {
      if (resultBmiNum) resultBmiNum.textContent = '—';
      if (resultBmrNum) resultBmrNum.textContent = '—';
      if (resultCategoryBadge) {
        resultCategoryBadge.textContent = 'Awaiting Input';
        resultCategoryBadge.className = 'badge badge-neutral';
      }
      if (resultCategoryText) {
        resultCategoryText.textContent = 'Enter your measurements to calculate clinical BMI.';
      }
      if (needleLabel) needleLabel.textContent = 'Enter measurements';
      if (pediatricWarning) pediatricWarning.style.display = 'none';
    }

    // Render History Table
    if (tableBody) {
      if (metricsLogs.length === 0) {
        tableBody.innerHTML = `
          <tr>
            <td colspan="6" class="table-empty-cell">
              <div class="empty-state-wrap">
                <p class="empty-state-title">No measurements logged yet</p>
                <p class="empty-state-sub">Enter your height, weight, and age above to calculate your baseline metrics.</p>
              </div>
            </td>
          </tr>
        `;
      } else {
        let rows = '';
        metricsLogs.forEach(entry => {
          const cat = CalculatorService.getBMICategory(entry.bmi, entry.age);
          const bmrDisplay = entry.age < 18 || entry.bmr === null
            ? '<em class="text-amber">Pediatric Ref (Exempt)</em>'
            : `${entry.bmr.toLocaleString()} kcal/day`;

          rows += `
            <tr>
              <td class="font-mono text-secondary">${entry.date}</td>
              <td class="font-mono">${entry.weightKg} kg</td>
              <td class="font-mono">${entry.heightCm} cm</td>
              <td><span class="badge ${cat.badgeClass}">${entry.bmi}</span></td>
              <td>${bmrDisplay}</td>
              <td><span class="text-secondary">${cat.category}</span></td>
            </tr>
          `;
        });
        tableBody.innerHTML = rows;
      }
    }
  }
}

// Auto-initialize
if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => CalculatorPageController.init());
  } else {
    CalculatorPageController.init();
  }
}
