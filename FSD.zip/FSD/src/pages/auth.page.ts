/**
 * Ezia Authentication Controller (src/pages/auth.page.ts)
 * Strongly typed form validation, error handling, Web Crypto SHA-256 login & registration,
 * and transparent client-side sandbox architecture notices.
 */

import { AuthService, Toast } from '../index.js';
import { RegistrationData, Gender, UnitPreference } from '../types/user.js';

export class AuthPageController {
  public static init(): void {
    if (typeof document === 'undefined') return;

    if (document.getElementById('loginForm')) {
      this.initLoginForm();
    }

    if (document.getElementById('registerForm')) {
      this.initRegisterForm();
    }
  }

  // --- 1. Login Form Controller ---
  private static initLoginForm(): void {
    const form = document.getElementById('loginForm') as HTMLFormElement | null;
    const emailInput = document.getElementById('email') as HTMLInputElement | null;
    const passwordInput = document.getElementById('password') as HTMLInputElement | null;
    const emailError = document.getElementById('emailError');
    const passwordError = document.getElementById('passwordError');
    const statusMessage = document.getElementById('statusMessage');
    const togglePasswordBtn = document.getElementById('togglePassword');
    const forgotPasswordLink = document.getElementById('forgotPasswordLink');
    const guestLoginBtn = document.getElementById('guestLoginBtn');

    const urlParams = new URLSearchParams(window.location.search);
    const redirectTarget = urlParams.get('redirect') || 'dashboard.html';

    // Password visibility toggle
    if (togglePasswordBtn && passwordInput) {
      togglePasswordBtn.addEventListener('click', () => {
        const isPass = passwordInput.getAttribute('type') === 'password';
        passwordInput.setAttribute('type', isPass ? 'text' : 'password');
        togglePasswordBtn.setAttribute('aria-label', isPass ? 'Hide password' : 'Show password');
        const eye = togglePasswordBtn.querySelector('.eye-symbol');
        if (eye) {
          eye.innerHTML = isPass
            ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>'
            : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>';
        }
      });
    }

    // Forgot password modal / toast guidance
    if (forgotPasswordLink) {
      forgotPasswordLink.addEventListener('click', (e: MouseEvent) => {
        e.preventDefault();
        Toast.info('Passwords are held securely on your device. Create a new profile on the registration page if needed.');
      });
    }

    // Instant Guest Mode button
    if (guestLoginBtn) {
      guestLoginBtn.addEventListener('click', () => {
        AuthService.loginAsGuest();
        Toast.success('Entering Ezia as Guest Explorer...');
        setTimeout(() => {
          window.location.href = `./${redirectTarget}`;
        }, 300);
      });
    }

    // Real-time input clearance
    emailInput?.addEventListener('input', () => this.clearField(emailInput, emailError));
    passwordInput?.addEventListener('input', () => this.clearField(passwordInput, passwordError));

    // Submit handler
    if (form && emailInput && passwordInput) {
      form.addEventListener('submit', async (e: SubmitEvent) => {
        e.preventDefault();
        this.clearField(emailInput, emailError);
        this.clearField(passwordInput, passwordError);
        this.hideStatus(statusMessage);

        const email = emailInput.value.trim();
        const password = passwordInput.value;

        // Validation
        let hasError = false;
        if (!email) {
          this.setField(emailInput, emailError, 'Email address is required.');
          hasError = true;
        } else if (!this.isValidEmail(email)) {
          this.setField(emailInput, emailError, 'Please enter a valid email address.');
          hasError = true;
        }

        if (!password) {
          this.setField(passwordInput, passwordError, 'Password is required.');
          hasError = true;
        }

        if (hasError) return;

        // Submit via AuthService
        this.showStatus(statusMessage, 'Verifying credentials with Web Crypto...', 'info');
        const result = await AuthService.login(email, password);

        if (result.success) {
          this.showStatus(statusMessage, `Welcome back, ${result.user?.name || 'Member'}! Redirecting...`, 'success');
          setTimeout(() => {
            window.location.href = `./${redirectTarget}`;
          }, 350);
        } else {
          this.showStatus(statusMessage, result.error || 'Authentication failed. Please verify your credentials.', 'error');
          this.setField(passwordInput, passwordError, 'Please check your password.');
        }
      });
    }
  }

  // --- 2. Registration Form Controller ---
  private static initRegisterForm(): void {
    const form = document.getElementById('registerForm') as HTMLFormElement | null;
    const nameInput = document.getElementById('regName') as HTMLInputElement | null;
    const emailInput = document.getElementById('regEmail') as HTMLInputElement | null;
    const ageInput = document.getElementById('regAge') as HTMLInputElement | null;
    const genderSelect = document.getElementById('regGender') as HTMLSelectElement | null;
    const unitSelect = document.getElementById('regUnits') as HTMLSelectElement | null;
    const passwordInput = document.getElementById('regPassword') as HTMLInputElement | null;
    const termsCheck = document.getElementById('termsCheck') as HTMLInputElement | null;

    const nameError = document.getElementById('nameError');
    const emailError = document.getElementById('emailError');
    const ageError = document.getElementById('ageError');
    const passwordError = document.getElementById('passwordError');
    const termsError = document.getElementById('termsError');
    const statusMessage = document.getElementById('registerStatus');
    const registerGuestBtn = document.getElementById('registerGuestBtn');

    // Instant Guest Mode button
    if (registerGuestBtn) {
      registerGuestBtn.addEventListener('click', (e: MouseEvent) => {
        e.preventDefault();
        AuthService.loginAsGuest();
        Toast.success('Entering Ezia as Guest Explorer...');
        setTimeout(() => {
          window.location.href = './dashboard.html';
        }, 300);
      });
    }

    // Real-time clearance
    nameInput?.addEventListener('input', () => this.clearField(nameInput, nameError));
    emailInput?.addEventListener('input', () => this.clearField(emailInput, emailError));
    ageInput?.addEventListener('input', () => this.clearField(ageInput, ageError));
    passwordInput?.addEventListener('input', () => this.clearField(passwordInput, passwordError));
    termsCheck?.addEventListener('change', () => this.clearField(termsCheck, termsError));

    if (form && nameInput && emailInput && ageInput && passwordInput && termsCheck) {
      form.addEventListener('submit', async (e: SubmitEvent) => {
        e.preventDefault();
        this.clearField(nameInput, nameError);
        this.clearField(emailInput, emailError);
        this.clearField(ageInput, ageError);
        this.clearField(passwordInput, passwordError);
        this.clearField(termsCheck, termsError);
        this.hideStatus(statusMessage);

        const name = nameInput.value.trim();
        const email = emailInput.value.trim();
        const ageNum = parseInt(ageInput.value, 10);
        const gender = (genderSelect ? genderSelect.value : 'female') as Gender;
        const unitPreference = (unitSelect ? unitSelect.value : 'metric') as UnitPreference;
        const password = passwordInput.value;
        const termsAccepted = termsCheck.checked;

        let hasError = false;

        if (!name) {
          this.setField(nameInput, nameError, 'Full name is required.');
          hasError = true;
        } else if (name.length < 2) {
          this.setField(nameInput, nameError, 'Name must be at least 2 characters.');
          hasError = true;
        }

        if (!email) {
          this.setField(emailInput, emailError, 'Email address is required.');
          hasError = true;
        } else if (!this.isValidEmail(email)) {
          this.setField(emailInput, emailError, 'Please enter a valid email address.');
          hasError = true;
        }

        if (isNaN(ageNum) || ageNum < 12 || ageNum > 120) {
          this.setField(ageInput, ageError, 'Please enter a valid age between 12 and 120.');
          hasError = true;
        }

        if (!password) {
          this.setField(passwordInput, passwordError, 'Password is required.');
          hasError = true;
        } else if (password.length < 8) {
          this.setField(passwordInput, passwordError, 'Password must be at least 8 characters long.');
          hasError = true;
        }

        if (!termsAccepted) {
          this.setField(termsCheck, termsError, 'You must acknowledge the terms to continue.');
          hasError = true;
        }

        if (hasError) return;

        this.showStatus(statusMessage, 'Generating cryptographic keys and creating profile...', 'info');

        const registrationPayload: RegistrationData = {
          name,
          email,
          password,
          age: ageNum,
          gender,
          unitPreference
        };

        const result = await AuthService.register(registrationPayload);

        if (result.success) {
          this.showStatus(statusMessage, 'Account created successfully! Preparing your dashboard...', 'success');
          setTimeout(() => {
            window.location.href = './dashboard.html';
          }, 400);
        } else {
          this.showStatus(statusMessage, result.error || 'Registration could not be completed.', 'error');
        }
      });
    }
  }

  // --- Shared Validation Helpers ---
  private static isValidEmail(email: string): boolean {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  private static setField(input: HTMLElement, errorEl: HTMLElement | null, message: string): void {
    input.classList.add('input-invalid');
    input.setAttribute('aria-invalid', 'true');
    if (errorEl) {
      errorEl.textContent = message;
      errorEl.style.display = 'block';
    }
  }

  private static clearField(input: HTMLElement, errorEl: HTMLElement | null): void {
    input.classList.remove('input-invalid');
    input.removeAttribute('aria-invalid');
    if (errorEl) {
      errorEl.textContent = '';
      errorEl.style.display = 'none';
    }
  }

  private static showStatus(el: HTMLElement | null, message: string, type: 'info' | 'success' | 'error'): void {
    if (!el) return;
    el.textContent = message;
    el.className = `status-message status-${type}`;
    el.style.display = 'block';
  }

  private static hideStatus(el: HTMLElement | null): void {
    if (!el) return;
    el.textContent = '';
    el.style.display = 'none';
  }
}

// Auto-initialize
if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => AuthPageController.init());
  } else {
    AuthPageController.init();
  }
}
