/**
 * Ezia Executive Wellness Dashboard Controller (src/pages/dashboard.page.ts)
 * Strongly typed TypeScript controller for the bento wellness overview.
 */

import {
  AuthService,
  StorageService,
  CalculatorService,
  SidebarController,
  DateBadge,
  Toast
} from '../index.js';
import { DailyWellnessScore, SleepLog, BodyMetricEntry } from '../types/health.js';

export class DashboardPageController {
  public static init(): void {
    if (typeof document === 'undefined') return;

    // 1. Initialize Reusable Sidebar & User Profile Header
    SidebarController.init();

    // 2. Initialize Date Badge
    DateBadge.init('headerDateBadge');

    // 3. Personalized Greeting
    this.initGreeting();

    // 4. Quick-Log Water Action
    const quickLogBtn = document.getElementById('quickLogWaterBtn');
    if (quickLogBtn) {
      quickLogBtn.addEventListener('click', () => {
        StorageService.addHydrationEntry(250);
        Toast.success('Logged +250 ml water');
        this.render();
      });
    }

    // 5. Initial Render
    this.render();
  }

  private static initGreeting(): void {
    const user = AuthService.getCurrentUser();
    const profile = StorageService.getProfile();
    const isGuest = user && user.isGuest;
    const activeName = (user && user.name) || profile.name || (isGuest ? 'Guest Explorer' : 'Member');

    const greetingHeading = document.getElementById('greetingHeading');
    if (greetingHeading) {
      const hour = new Date().getHours();
      let timeGreeting = 'Good morning';
      if (hour >= 12 && hour < 17) timeGreeting = 'Good afternoon';
      else if (hour >= 17) timeGreeting = 'Good evening';
      greetingHeading.textContent = `${timeGreeting}, ${activeName}`;
      greetingHeading.style.visibility = 'visible';
    }
  }

  public static render(): void {
    const todayStr = new Date().toISOString().split('T')[0];
    const wellnessData = CalculatorService.calculateDailyWellnessScore(todayStr);

    this.renderWellnessScore(wellnessData);
    this.renderHydrationCard(wellnessData);
    this.renderSleepCard(todayStr);
    this.renderBodyMetricsCard();
    this.renderSevenDayTrendChart();
    this.renderWellnessNotes(wellnessData);
  }

  private static renderWellnessScore(wellness: DailyWellnessScore): void {
    const scoreValEl = document.getElementById('wellnessScoreVal');
    const scoreArc = document.getElementById('scoreProgressArc') as SVGCircleElement | null;
    const scoreHydrationPart = document.getElementById('scoreHydrationPart');
    const scoreSleepPart = document.getElementById('scoreSleepPart');
    const scoreConsistencyPart = document.getElementById('scoreConsistencyPart');
    const wellnessSummary = document.getElementById('wellnessSummary');

    if (scoreValEl) scoreValEl.textContent = wellness.hasData ? String(wellness.totalScore) : '0';
    if (scoreHydrationPart) scoreHydrationPart.textContent = `${wellness.components.hydration} / 40`;
    if (scoreSleepPart) scoreSleepPart.textContent = `${wellness.components.sleep} / 40`;
    if (scoreConsistencyPart) scoreConsistencyPart.textContent = `${wellness.components.consistency} / 20`;

    if (scoreArc) {
      const circumference = 364.42;
      const score = wellness.hasData ? wellness.totalScore : 0;
      const offset = circumference - (circumference * (score / 100));
      scoreArc.style.strokeDashoffset = String(Math.max(0, offset));
    }

    if (wellnessSummary) {
      if (!wellness.hasData) {
        wellnessSummary.textContent = 'Welcome to Ezia! You have not logged water or sleep for today yet. Record an entry below to see your daily score.';
      } else if (wellness.totalScore >= 80) {
        wellnessSummary.textContent = 'Great progress today! Your hydration and sleep targets are well balanced.';
      } else if (wellness.totalScore >= 50) {
        wellnessSummary.textContent = 'Steady progress today. Remember to drink water this afternoon and wind down for good rest tonight.';
      } else {
        wellnessSummary.textContent = 'A gentle reminder to stay hydrated and log your sleep patterns as your day unfolds.';
      }
    }
  }

  private static renderHydrationCard(wellness: DailyWellnessScore): void {
    const metricWaterVal = document.getElementById('metricWaterVal');
    const metricWaterBar = document.getElementById('metricWaterBar') as HTMLElement | null;
    const metricWaterContext = document.getElementById('metricWaterContext');

    const totalWater = wellness.hydrationLoggedMl;
    const waterGoal = wellness.hydrationGoalMl || 2500;
    const waterPercent = Math.min(100, Math.round((totalWater / waterGoal) * 100));

    if (metricWaterVal) metricWaterVal.textContent = totalWater.toLocaleString();
    if (metricWaterBar) metricWaterBar.style.width = `${waterPercent}%`;
    if (metricWaterContext) {
      metricWaterContext.textContent = `${waterPercent}% of ${waterGoal.toLocaleString()} ml personal target`;
    }
  }

  private static renderSleepCard(todayStr: string): void {
    const metricSleepVal = document.getElementById('metricSleepVal');
    const metricSleepStars = document.getElementById('metricSleepStars');
    const metricSleepContext = document.getElementById('metricSleepContext');

    const sleepLogs = StorageService.getSleepLogs();
    const todaySleep = sleepLogs.find(item => item.date === todayStr);

    if (todaySleep) {
      if (metricSleepVal) metricSleepVal.textContent = String(todaySleep.durationHours);
      if (metricSleepStars) {
        const fullStars = '★'.repeat(todaySleep.restfulness || 0);
        const emptyStars = '☆'.repeat(Math.max(0, 5 - (todaySleep.restfulness || 0)));
        metricSleepStars.textContent = fullStars + emptyStars;
      }
      if (metricSleepContext) {
        metricSleepContext.textContent = `Logged ${todaySleep.durationHours} hrs (${todaySleep.bedtime || ''} - ${todaySleep.wakeTime || ''})`;
      }
    } else if (sleepLogs.length > 0) {
      const latest = sleepLogs[0];
      if (metricSleepVal) metricSleepVal.textContent = String(latest.durationHours);
      if (metricSleepStars) {
        const fullStars = '★'.repeat(latest.restfulness || 0);
        const emptyStars = '☆'.repeat(Math.max(0, 5 - (latest.restfulness || 0)));
        metricSleepStars.textContent = fullStars + emptyStars;
      }
      if (metricSleepContext) {
        metricSleepContext.textContent = `Latest log: ${latest.durationHours} hrs (${latest.date})`;
      }
    } else {
      if (metricSleepVal) metricSleepVal.textContent = '—';
      if (metricSleepStars) metricSleepStars.textContent = '☆☆☆☆☆';
      if (metricSleepContext) metricSleepContext.textContent = 'No sleep logged for today yet';
    }
  }

  private static renderBodyMetricsCard(): void {
    const metricBmiVal = document.getElementById('metricBmiVal');
    const metricBmiBadge = document.getElementById('metricBmiBadge');
    const metricBmiContext = document.getElementById('metricBmiContext');

    const metricsLogs = StorageService.getBodyMetrics();
    if (metricsLogs.length > 0) {
      const latest = metricsLogs[0];
      if (metricBmiVal) metricBmiVal.textContent = String(latest.bmi);
      const cat = CalculatorService.getBMICategory(latest.bmi, latest.age);
      if (metricBmiBadge) {
        metricBmiBadge.textContent = cat.category;
        metricBmiBadge.className = `badge ${cat.badgeClass}`;
      }
      if (metricBmiContext) {
        metricBmiContext.textContent = `Weight: ${latest.weightKg} kg · Height: ${latest.heightCm} cm`;
      }
    } else {
      if (metricBmiVal) metricBmiVal.textContent = '—';
      if (metricBmiBadge) {
        metricBmiBadge.textContent = 'Unrecorded';
        metricBmiBadge.className = 'badge badge-neutral';
      }
      if (metricBmiContext) {
        metricBmiContext.textContent = 'No measurements logged yet';
      }
    }
  }

  private static renderSevenDayTrendChart(): void {
    const container = document.getElementById('sevenDayChartContainer');
    if (!container) return;

    const hydLogs = StorageService.getHydrationLogs();
    const sleepLogs = StorageService.getSleepLogs();

    const days: Array<{ dayLabel: string; dateStr: string; water: number; sleep: number }> = [];
    const today = new Date();

    for (let i = 6; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const dayLabel = d.toLocaleDateString([], { weekday: 'short' });

      const dayWater = hydLogs
        .filter(item => item.date === dateStr)
        .reduce((sum, item) => sum + item.amountMl, 0);

      const daySleepItem = sleepLogs.find(item => item.date === dateStr);
      const daySleepHours = daySleepItem ? daySleepItem.durationHours : 0;

      days.push({ dayLabel, dateStr, water: dayWater, sleep: daySleepHours });
    }

    const hasAnyWeeklyData = days.some(d => d.water > 0 || d.sleep > 0);

    if (!hasAnyWeeklyData) {
      container.innerHTML = `
        <div class="chart-empty-state">
          <img src="./assets/illustrations/empty-state.svg" alt="" width="64" height="64" class="empty-state-icon">
          <h4>No Trend Data Available Yet</h4>
          <p>Log your daily water intake and sleep to generate your 7-day longitudinal trends.</p>
        </div>
      `;
      return;
    }

    const maxWater = Math.max(3000, ...days.map(d => d.water));
    const maxSleep = 12.0;

    let barsHtml = '';
    days.forEach(day => {
      const waterHeightPct = Math.min(100, Math.round((day.water / maxWater) * 85));
      const sleepHeightPct = Math.min(100, Math.round((day.sleep / maxSleep) * 85));

      barsHtml += `
        <div class="chart-col">
          <div class="chart-col-bars">
            <div class="chart-bar bar-teal" style="height: ${Math.max(4, waterHeightPct)}%;" title="${day.dayLabel}: ${day.water.toLocaleString()} ml water"></div>
            <div class="chart-bar bar-mint" style="height: ${Math.max(4, sleepHeightPct)}%;" title="${day.dayLabel}: ${day.sleep} hrs sleep"></div>
          </div>
          <span class="chart-col-label">${day.dayLabel}</span>
        </div>
      `;
    });

    container.innerHTML = `<div class="chart-bars-wrap">${barsHtml}</div>`;
  }

  private static renderWellnessNotes(wellness: DailyWellnessScore): void {
    const list = document.getElementById('dashboardNotesList');
    if (!list) return;

    if (!wellness.hasData) {
      list.innerHTML = `
        <div class="note-card note-neutral">
          <span class="note-tag">Welcome</span>
          <h4>Ready for Your First Entry</h4>
          <p>Ezia tracks your wellness habits from your actual daily logs. Use the +250 ml Water button or log your sleep to begin.</p>
        </div>
      `;
      return;
    }

    const notes: string[] = [];

    if (wellness.hydrationLoggedMl >= wellness.hydrationGoalMl) {
      notes.push(`
        <div class="note-card note-mint">
          <span class="note-tag">Goal Reached</span>
          <h4>Target Achieved (${wellness.hydrationLoggedMl.toLocaleString()} ml)</h4>
          <p>Your daily hydration goal is met today! Staying well-hydrated helps sustain focus, mood, and steady energy.</p>
        </div>
      `);
    } else {
      const remaining = wellness.hydrationGoalMl - wellness.hydrationLoggedMl;
      notes.push(`
        <div class="note-card note-teal">
          <span class="note-tag">Hydration Goal</span>
          <h4>${remaining.toLocaleString()} ml Remaining</h4>
          <p>Keep a water bottle handy and take sips throughout your day to reach your target.</p>
        </div>
      `);
    }

    if (wellness.sleepLoggedHours >= 7.0) {
      notes.push(`
        <div class="note-card note-mint">
          <span class="note-tag">Restful Sleep</span>
          <h4>Great Rest (${wellness.sleepLoggedHours} hrs)</h4>
          <p>Getting 7+ hours of quality sleep helps recharge your energy, mental focus, and body recovery.</p>
        </div>
      `);
    }

    list.innerHTML = notes.join('');
  }
}

// Auto-initialize
if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => DashboardPageController.init());
  } else {
    DashboardPageController.init();
  }
}
