/**
 * Ezia Landing Page Controller (src/pages/landing.page.ts)
 * Strongly typed TypeScript controller for the modern editorial wellness experience.
 */

import { AuthService, DateBadge, StorageService } from '../index.js';

export class LandingPageController {
  public static init(): void {
    if (typeof document === 'undefined') return;

    // 1. Dynamic Live Date in Hero Preview
    this.initHeroDate();

    // 2. Setup Guest Mode Entry Handlers
    this.initGuestButtons();

    // 3. Dynamic Session Awareness & Hero Personalization
    this.personalizeHeroForActiveUser();

    // 4. Subtle Interactive Preview Micro-Interactions
    this.initHeroInteractivePreview();

    // 5. Accessible Smooth Navigation
    this.initSmoothNav();
  }

  private static initHeroDate(): void {
    const dateEl = document.getElementById('heroLiveDate');
    if (dateEl) {
      const now = new Date();
      dateEl.textContent = 'Today, ' + now.toLocaleDateString([], {
        month: 'short',
        day: 'numeric'
      });
    }
  }

  private static initGuestButtons(): void {
    const guestButtons = [
      document.getElementById('heroGuestBtn'),
      document.getElementById('navGuestBtn'),
      document.getElementById('heroPreviewCta')
    ];

    guestButtons.forEach(btn => {
      if (btn) {
        btn.addEventListener('click', (e: MouseEvent) => {
          if (!AuthService.isAuthenticated()) {
            AuthService.loginAsGuest();
          }
        });
      }
    });
  }

  private static personalizeHeroForActiveUser(): void {
    if (AuthService.isAuthenticated()) {
      const user = AuthService.getCurrentUser();
      const profile = StorageService.getProfile();
      const displayName = (user && user.name) || profile.name || (user?.isGuest ? 'Guest Explorer' : 'Member');

      // Update Hero Primary CTA
      const heroPrimaryBtn = document.getElementById('heroGuestBtn');
      if (heroPrimaryBtn) {
        heroPrimaryBtn.setAttribute('href', './dashboard.html');
        heroPrimaryBtn.innerHTML = `
          <span>Resume Session &middot; ${displayName}</span>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
        `;
      }

      // Update Nav Guest Button to direct Dashboard link
      const navGuestBtn = document.getElementById('navGuestBtn');
      if (navGuestBtn) {
        navGuestBtn.textContent = 'Go to Dashboard →';
        navGuestBtn.setAttribute('href', './dashboard.html');
      }

      // Hide or adjust secondary sign in link
      const heroSecondaryBtn = document.querySelector<HTMLAnchorElement>('.hero-cta-group .btn-secondary');
      if (heroSecondaryBtn) {
        heroSecondaryBtn.textContent = 'Account Overview';
        heroSecondaryBtn.setAttribute('href', './settings.html');
      }
    }
  }

  private static initHeroInteractivePreview(): void {
    const previewCard = document.querySelector<HTMLElement>('.bento-preview-card');
    if (!previewCard) return;

    // Subtle 3D tilt interaction on hover (reduced-motion safe)
    const prefersReducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!prefersReducedMotion) {
      previewCard.addEventListener('mousemove', (e: MouseEvent) => {
        const rect = previewCard.getBoundingClientRect();
        const x = e.clientX - rect.left - rect.width / 2;
        const y = e.clientY - rect.top - rect.height / 2;
        const rotateX = -(y / rect.height) * 8;
        const rotateY = (x / rect.width) * 8;
        previewCard.style.transform = `perspective(1000px) rotateX(${rotateX.toFixed(2)}deg) rotateY(${rotateY.toFixed(2)}deg) translateY(-4px)`;
      });

      previewCard.addEventListener('mouseleave', () => {
        previewCard.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0)';
        previewCard.style.transition = 'transform 0.4s ease';
      });

      previewCard.addEventListener('mouseenter', () => {
        previewCard.style.transition = 'transform 0.1s ease';
      });
    }
  }

  private static initSmoothNav(): void {
    document.querySelectorAll<HTMLAnchorElement>('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', (e: MouseEvent) => {
        const href = anchor.getAttribute('href');
        if (href && href !== '#') {
          const target = document.querySelector(href);
          if (target) {
            e.preventDefault();
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            // Update active state in nav
            document.querySelectorAll('.public-nav a').forEach(a => a.classList.remove('active'));
            anchor.classList.add('active');
          }
        }
      });
    });
  }
}

// Auto-initialize when DOM is ready
if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => LandingPageController.init());
  } else {
    LandingPageController.init();
  }
}
