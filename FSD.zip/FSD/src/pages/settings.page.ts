/**
 * Ezia Target Settings & Preferences Controller (src/pages/settings.page.ts)
 * Strongly typed TypeScript controller for profile calibration, target goals, and data management.
 */

import {
  AuthService,
  StorageService,
  SidebarController,
  Toast
} from '../index.js';
import { Gender, UnitPreference } from '../types/user.js';

export class SettingsPageController {
  public static init(): void {
    if (typeof document === 'undefined') return;

    // 1. Navigation & Profile
    SidebarController.init();

    // 2. Populate form fields
    this.populateForms();

    // 3. Profile Settings Form Submit
    const profileForm = document.getElementById('profileSettingsForm') as HTMLFormElement | null;
    if (profileForm) {
      profileForm.addEventListener('submit', (e: SubmitEvent) => {
        e.preventDefault();
        this.saveProfileSettings();
      });
    }

    // 4. Target Goals Form Submit
    const targetsForm = document.getElementById('targetsSettingsForm') as HTMLFormElement | null;
    if (targetsForm) {
      targetsForm.addEventListener('submit', (e: SubmitEvent) => {
        e.preventDefault();
        this.saveTargetGoals();
      });
    }

    // 5. Data Actions
    this.initDataActions();
  }

  private static populateForms(): void {
    const profile = StorageService.getProfile();
    const user = AuthService.getCurrentUser();

    const nameInput = document.getElementById('setProfileName') as HTMLInputElement | null;
    const emailInput = document.getElementById('setProfileEmail') as HTMLInputElement | null;
    const ageInput = document.getElementById('setProfileAge') as HTMLInputElement | null;
    const genderSelect = document.getElementById('setProfileGender') as HTMLSelectElement | null;
    const unitSelect = document.getElementById('setUnitPref') as HTMLSelectElement | null;

    const waterGoalInput = document.getElementById('setWaterGoal') as HTMLInputElement | null;
    const sleepGoalInput = document.getElementById('setSleepGoal') as HTMLInputElement | null;

    if (nameInput) nameInput.value = (user && user.name) || profile.name || '';
    if (emailInput) emailInput.value = (user && user.email) || profile.email || '';
    if (ageInput) ageInput.value = String(profile.age || 28);
    if (genderSelect && profile.gender) genderSelect.value = profile.gender;
    if (unitSelect && profile.unitPreference) unitSelect.value = profile.unitPreference;

    if (waterGoalInput) waterGoalInput.value = String(profile.waterGoalMl || 2500);
    if (sleepGoalInput) sleepGoalInput.value = String(profile.sleepGoalHrs || 8.0);
  }

  private static saveProfileSettings(): void {
    const nameInput = document.getElementById('setProfileName') as HTMLInputElement | null;
    const emailInput = document.getElementById('setProfileEmail') as HTMLInputElement | null;
    const ageInput = document.getElementById('setProfileAge') as HTMLInputElement | null;
    const genderSelect = document.getElementById('setProfileGender') as HTMLSelectElement | null;
    const unitSelect = document.getElementById('setUnitPref') as HTMLSelectElement | null;

    const name = nameInput ? nameInput.value.trim() : '';
    const email = emailInput ? emailInput.value.trim() : '';
    const age = ageInput ? parseInt(ageInput.value, 10) : 28;
    const gender = (genderSelect ? genderSelect.value : 'female') as Gender;
    const unitPreference = (unitSelect ? unitSelect.value : 'metric') as UnitPreference;

    if (!name) {
      Toast.error('Please enter your full name.');
      return;
    }

    if (isNaN(age) || age < 10 || age > 120) {
      Toast.error('Please enter a valid age (10 - 120 years).');
      return;
    }

    StorageService.saveProfile({
      name,
      email,
      age,
      gender,
      unitPreference
    });

    // Also update settings unit
    StorageService.saveSettings({ unit: unitPreference });

    Toast.success('Profile calibrations saved successfully.');
    SidebarController.init();
  }

  private static saveTargetGoals(): void {
    const waterGoalInput = document.getElementById('setWaterGoal') as HTMLInputElement | null;
    const sleepGoalInput = document.getElementById('setSleepGoal') as HTMLInputElement | null;

    const waterGoalMl = waterGoalInput ? parseInt(waterGoalInput.value, 10) : 2500;
    const sleepGoalHrs = sleepGoalInput ? parseFloat(sleepGoalInput.value) : 8.0;

    if (isNaN(waterGoalMl) || waterGoalMl < 500 || waterGoalMl > 8000) {
      Toast.error('Please specify a realistic water goal (500 - 8000 ml).');
      return;
    }

    if (isNaN(sleepGoalHrs) || sleepGoalHrs < 4 || sleepGoalHrs > 16) {
      Toast.error('Please specify a realistic sleep target (4 - 16 hours).');
      return;
    }

    StorageService.saveProfile({
      waterGoalMl,
      sleepGoalHrs
    });

    Toast.success('Daily target goals updated successfully.');
  }

  private static initDataActions(): void {
    // 1. Export JSON Data
    const exportBtn = document.getElementById('exportDataBtn');
    if (exportBtn) {
      exportBtn.addEventListener('click', () => {
        const jsonStr = StorageService.exportAllJSON();
        const blob = new Blob([jsonStr], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `ezia_wellness_backup_${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        Toast.success('Backup downloaded successfully.');
      });
    }

    // 2. Print Summary
    const printBtn = document.getElementById('settingsPrintBtn');
    if (printBtn) {
      printBtn.addEventListener('click', () => {
        window.print();
      });
    }

    // 3. Clear Personal Logs
    const clearLogsBtn = document.getElementById('clearLogsBtn');
    if (clearLogsBtn) {
      clearLogsBtn.addEventListener('click', () => {
        if (confirm('Are you sure you want to erase your hydration and sleep habit logs? Your profile calibration and targets will be kept.')) {
          StorageService.resetUserLogs();
          Toast.info('Personal logs have been cleared.');
        }
      });
    }

    // 4. Delete Account
    const deleteAccountBtn = document.getElementById('deleteAccountBtn');
    if (deleteAccountBtn) {
      deleteAccountBtn.addEventListener('click', () => {
        if (confirm('WARNING: Are you sure you wish to permanently delete your account and all private biometric records? This cannot be undone.')) {
          AuthService.deleteAccount();
          Toast.info('Account and data deleted.');
          setTimeout(() => {
            window.location.href = './login.html';
          }, 350);
        }
      });
    }
  }
}

// Auto-initialize
if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => SettingsPageController.init());
  } else {
    SettingsPageController.init();
  }
}
