/**
 * Ezia Evidence Insights Controller (src/pages/insights.page.ts)
 * Strongly typed TypeScript controller for generating transparent, non-fabricated reflections.
 */

import {
  StorageService,
  SidebarController
} from '../index.js';

interface InsightItem {
  id: string;
  category: 'hydration' | 'sleep' | 'general';
  badgeClass: string;
  badgeText: string;
  title: string;
  body: string;
  triggeredBy: string;
}

export class InsightsPageController {
  private static activeFilter: 'all' | 'hydration' | 'sleep' | 'general' = 'all';

  public static init(): void {
    if (typeof document === 'undefined') return;

    // 1. Navigation & Profile
    SidebarController.init();

    // 2. Filter Pills
    const filterBtns = document.querySelectorAll<HTMLButtonElement>('.filter-pill');
    filterBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.activeFilter = (btn.getAttribute('data-filter') || 'all') as any;
        this.render();
      });
    });

    // 3. Initial Render
    this.render();
  }

  public static render(): void {
    const hydLogs = StorageService.getHydrationLogs();
    const sleepLogs = StorageService.getSleepLogs();
    const metricsLogs = StorageService.getBodyMetrics();
    const profile = StorageService.getProfile();

    // 1. Calculate Summary Ribbon Stats
    const avgHydrationEl = document.getElementById('avgHydrationStat');
    const avgSleepEl = document.getElementById('avgSleepStat');
    const consistencyEl = document.getElementById('consistencyStat');

    // Distinct dates in hydration and sleep
    const uniqueDays = new Set<string>();
    hydLogs.forEach(h => uniqueDays.add(h.date));
    sleepLogs.forEach(s => uniqueDays.add(s.date));

    // Hydration daily totals
    const waterByDate: Record<string, number> = {};
    hydLogs.forEach(h => {
      waterByDate[h.date] = (waterByDate[h.date] || 0) + h.amountMl;
    });
    const waterDays = Object.values(waterByDate);
    const avgWater = waterDays.length > 0 ? Math.round(waterDays.reduce((a, b) => a + b, 0) / waterDays.length) : 0;

    // Sleep average
    const sleepDurations = sleepLogs.map(s => s.durationHours);
    const avgSleep = sleepDurations.length > 0
      ? Number((sleepDurations.reduce((a, b) => a + b, 0) / sleepDurations.length).toFixed(1))
      : 0;

    // Regularity in last 7 days
    const today = new Date();
    let loggedInLast7 = 0;
    for (let i = 0; i < 7; i++) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      const ds = d.toISOString().split('T')[0];
      if (uniqueDays.has(ds)) loggedInLast7++;
    }

    if (avgHydrationEl) avgHydrationEl.textContent = avgWater > 0 ? `${avgWater.toLocaleString()} ml / day` : '— ml / day';
    if (avgSleepEl) avgSleepEl.textContent = avgSleep > 0 ? `${avgSleep} hrs / night` : '— hrs / night';
    if (consistencyEl) consistencyEl.textContent = `${loggedInLast7} of last 7 days`;

    // 2. Generate Evidence-Based Insights
    const container = document.getElementById('insightsCardsContainer');
    if (!container) return;

    const insights = this.generateInsights(avgWater, avgSleep, loggedInLast7, profile, metricsLogs);
    const filtered = this.activeFilter === 'all'
      ? insights
      : insights.filter(item => item.category === this.activeFilter);

    if (filtered.length === 0) {
      container.innerHTML = `
        <div class="empty-state-wrap card">
          <img src="./assets/illustrations/empty-state.svg" alt="" width="64" height="64" class="empty-state-icon">
          <p class="empty-state-title">Awaiting Logged Data</p>
          <p class="empty-state-sub">Ezia generates reflections exclusively from authentic data. Record hydration or sleep to unlock personalized insights.</p>
        </div>
      `;
      return;
    }

    let cardsHtml = '';
    filtered.forEach(item => {
      cardsHtml += `
        <article class="card insight-card" id="${item.id}">
          <div class="insight-card-header">
            <span class="badge ${item.badgeClass}">${item.badgeText}</span>
            <span class="insight-trigger-tag">${item.triggeredBy}</span>
          </div>
          <h3 class="insight-title font-serif">${item.title}</h3>
          <p class="insight-body">${item.body}</p>
        </article>
      `;
    });

    container.innerHTML = cardsHtml;
  }

  private static generateInsights(
    avgWater: number,
    avgSleep: number,
    daysLogged: number,
    profile: any,
    metricsLogs: any[]
  ): InsightItem[] {
    const list: InsightItem[] = [];

    // Hydration Insights
    if (avgWater > 0) {
      const goal = profile.waterGoalMl || 2500;
      if (avgWater >= goal) {
        list.push({
          id: 'ins-hyd-optimum',
          category: 'hydration',
          badgeClass: 'badge-mint',
          badgeText: 'Optimal Hydration',
          title: 'Cellular Fluid Balance Achieved',
          body: `Your average daily volume of ${avgWater.toLocaleString()} ml satisfies your daily target (${goal.toLocaleString()} ml). Optimal hydration improves intracellular osmolarity, joint lubrication, and daytime cognitive alertness.`,
          triggeredBy: `Average Intake: ${avgWater} ml`
        });
      } else {
        const gap = goal - avgWater;
        list.push({
          id: 'ins-hyd-deficit',
          category: 'hydration',
          badgeClass: 'badge-teal',
          badgeText: 'Hydration Pacing',
          title: 'Opportunity to Distribute Fluids',
          body: `You are averaging ${avgWater.toLocaleString()} ml daily, approximately ${gap.toLocaleString()} ml below target. Consider sipping an extra glass mid-morning and mid-afternoon to maintain renal equilibrium without evening disruption.`,
          triggeredBy: `Target Deficit: ${gap} ml`
        });
      }
    }

    // Sleep Insights
    if (avgSleep > 0) {
      if (avgSleep >= 7.0 && avgSleep <= 9.0) {
        list.push({
          id: 'ins-sleep-restorative',
          category: 'sleep',
          badgeClass: 'badge-mint',
          badgeText: 'Circadian Equilibrium',
          title: 'Restorative Sleep Horizon Maintained',
          body: `A recorded average of ${avgSleep} hours rests squarely within the established physiological range for complete slow-wave and REM sleep cycles, supporting memory consolidation and cellular repair.`,
          triggeredBy: `Nightly Average: ${avgSleep} hrs`
        });
      } else if (avgSleep < 7.0) {
        list.push({
          id: 'ins-sleep-deficit',
          category: 'sleep',
          badgeClass: 'badge-amber',
          badgeText: 'Circadian Attention',
          title: 'Cumulative Sleep Debt Awareness',
          body: `Your recorded sleep duration averages ${avgSleep} hours. Chronic durations below seven hours may elevate cortisol and decrease daytime metabolic insulin sensitivity. Shifting bedtime 30 minutes earlier can help restore baseline balance.`,
          triggeredBy: `Average Rest: ${avgSleep} hrs`
        });
      }
    }

    // Regularity Insights
    if (daysLogged >= 4) {
      list.push({
        id: 'ins-reg-high',
        category: 'general',
        badgeClass: 'badge-teal',
        badgeText: 'Habit Stability',
        title: 'Strong Longitudinal Habit Formation',
        body: `You have maintained active logging across ${daysLogged} of the past 7 days. Consistency in self-monitoring is strongly correlated in behavioral medicine with enduring physiological resilience.`,
        triggeredBy: `Active Days: ${daysLogged} / 7`
      });
    }

    // Anthropometric Insights
    if (metricsLogs.length > 0) {
      const bm = metricsLogs[0];
      if (bm.age >= 18 && bm.bmr) {
        list.push({
          id: 'ins-bmr-estimate',
          category: 'general',
          badgeClass: 'badge-teal',
          badgeText: 'Metabolic Baseline',
          title: 'Resting Caloric Expenditure Baseline',
          body: `Based on your stature (${bm.heightCm} cm) and mass (${bm.weightKg} kg), your estimated basal metabolic rate is ${bm.bmr.toLocaleString()} kcal/day. This represents baseline cellular maintenance at complete physical rest before accounting for occupational activity.`,
          triggeredBy: `Mifflin-St Jeor: ${bm.bmr} kcal`
        });
      }
    }

    return list;
  }
}

// Auto-initialize
if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => InsightsPageController.init());
  } else {
    InsightsPageController.init();
  }
}
