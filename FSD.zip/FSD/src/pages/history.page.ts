/**
 * Ezia 7-Day History & Longitudinal Trends Controller (src/pages/history.page.ts)
 * Strongly typed TypeScript controller for trend visualizations and longitudinal analytics.
 */

import {
  StorageService,
  CalculatorService,
  SidebarController
} from '../index.js';

interface DailyHistoryRow {
  dateStr: string;
  dayLabel: string;
  waterMl: number;
  waterGoalMl: number;
  waterPercent: number;
  sleepHours: number;
  sleepRating: number;
  wellnessScore: number;
  hasData: boolean;
}

export class HistoryPageController {
  public static init(): void {
    if (typeof document === 'undefined') return;

    // 1. Navigation & Profile
    SidebarController.init();

    // 2. Print Clinical Summary Button
    const printBtn = document.getElementById('printReportBtn');
    if (printBtn) {
      printBtn.addEventListener('click', () => {
        window.print();
      });
    }

    // 3. Render Views
    this.render();
  }

  public static render(): void {
    const hydLogs = StorageService.getHydrationLogs();
    const sleepLogs = StorageService.getSleepLogs();
    const profile = StorageService.getProfile();
    const waterGoal = profile.waterGoalMl || 2500;
    const sleepGoal = profile.sleepGoalHrs || 8.0;

    // Generate 7 day chronological slice
    const days: DailyHistoryRow[] = [];
    const today = new Date();

    for (let i = 6; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const dayLabel = d.toLocaleDateString([], { weekday: 'short' });

      // Daily hydration
      const dayWater = hydLogs
        .filter(h => h.date === dateStr)
        .reduce((sum, h) => sum + h.amountMl, 0);

      // Daily sleep
      const sleepEntry = sleepLogs.find(s => s.date === dateStr);
      const sleepHours = sleepEntry ? sleepEntry.durationHours : 0;
      const sleepRating = sleepEntry ? sleepEntry.restfulness : 0;

      // Daily wellness score
      const wellness = CalculatorService.calculateDailyWellnessScore(dateStr);

      days.push({
        dateStr,
        dayLabel,
        waterMl: dayWater,
        waterGoalMl: waterGoal,
        waterPercent: Math.min(100, Math.round((dayWater / waterGoal) * 100)),
        sleepHours,
        sleepRating,
        wellnessScore: wellness.totalScore,
        hasData: dayWater > 0 || sleepHours > 0
      });
    }

    this.renderHydrationChart(days, waterGoal);
    this.renderSleepChart(days, sleepGoal);
    this.renderHistoryTable(days);
  }

  private static renderHydrationChart(days: DailyHistoryRow[], waterGoal: number): void {
    const container = document.getElementById('historyHydrationChart');
    if (!container) return;

    const hasData = days.some(d => d.waterMl > 0);
    if (!hasData) {
      container.innerHTML = `
        <div class="empty-state-wrap">
          <p class="empty-state-title">No hydration data recorded</p>
          <p class="empty-state-sub">Log daily water in the Hydration Vessel to visualize your 7-day intake curve.</p>
        </div>
      `;
      return;
    }

    const maxWater = Math.max(waterGoal * 1.2, ...days.map(d => d.waterMl), 3000);

    let bars = '';
    days.forEach(day => {
      const heightPct = Math.min(100, Math.round((day.waterMl / maxWater) * 100));
      bars += `
        <div class="chart-col">
          <div class="chart-bar-track">
            <div class="chart-bar-fill fill-teal" style="height: ${Math.max(4, heightPct)}%;" title="${day.dayLabel}: ${day.waterMl.toLocaleString()} ml"></div>
          </div>
          <span class="chart-col-label">${day.dayLabel}</span>
          <span class="chart-col-val font-mono">${day.waterMl > 0 ? day.waterMl.toLocaleString() : '—'}</span>
        </div>
      `;
    });

    container.innerHTML = `<div class="chart-cols-wrap">${bars}</div>`;
  }

  private static renderSleepChart(days: DailyHistoryRow[], sleepGoal: number): void {
    const container = document.getElementById('historySleepChart');
    if (!container) return;

    const hasData = days.some(d => d.sleepHours > 0);
    if (!hasData) {
      container.innerHTML = `
        <div class="empty-state-wrap">
          <p class="empty-state-title">No sleep data recorded</p>
          <p class="empty-state-sub">Record bedtime in the Sleep Sanctuary to plot your circadian rest pattern.</p>
        </div>
      `;
      return;
    }

    const maxSleep = 12.0;

    let bars = '';
    days.forEach(day => {
      const heightPct = Math.min(100, Math.round((day.sleepHours / maxSleep) * 100));
      bars += `
        <div class="chart-col">
          <div class="chart-bar-track">
            <div class="chart-bar-fill fill-mint" style="height: ${Math.max(4, heightPct)}%;" title="${day.dayLabel}: ${day.sleepHours} hrs"></div>
          </div>
          <span class="chart-col-label">${day.dayLabel}</span>
          <span class="chart-col-val font-mono">${day.sleepHours > 0 ? `${day.sleepHours}h` : '—'}</span>
        </div>
      `;
    });

    container.innerHTML = `<div class="chart-cols-wrap">${bars}</div>`;
  }

  private static renderHistoryTable(days: DailyHistoryRow[]): void {
    const tableBody = document.getElementById('historyTableBody');
    if (!tableBody) return;

    const hasAnyData = days.some(d => d.hasData);
    if (!hasAnyData) {
      tableBody.innerHTML = `
        <tr>
          <td colspan="7" class="table-empty-cell">
            <div class="empty-state-wrap">
              <p class="empty-state-title">No habit logs found for the past 7 days</p>
              <p class="empty-state-sub">Recorded water and sleep habits will populate your longitudinal clinical ledger automatically.</p>
            </div>
          </td>
        </tr>
      `;
      return;
    }

    let rows = '';
    days.slice().reverse().forEach(day => {
      const waterDisplay = day.waterMl > 0 ? `${day.waterMl.toLocaleString()} ml` : '<span class="text-muted">—</span>';
      const pctBadge = day.waterMl > 0
        ? `<span class="badge ${day.waterPercent >= 100 ? 'badge-mint' : 'badge-teal'}">${day.waterPercent}%</span>`
        : '<span class="text-muted">—</span>';
      const sleepDisplay = day.sleepHours > 0 ? `${day.sleepHours} hrs` : '<span class="text-muted">—</span>';
      const starsDisplay = day.sleepRating > 0
        ? `<span class="text-amber">${'★'.repeat(day.sleepRating)}${'☆'.repeat(5 - day.sleepRating)}</span>`
        : '<span class="text-muted">—</span>';
      const scoreBadge = day.hasData
        ? `<span class="badge ${day.wellnessScore >= 75 ? 'badge-mint' : day.wellnessScore >= 45 ? 'badge-teal' : 'badge-amber'}">${day.wellnessScore} / 100</span>`
        : '<span class="text-muted">—</span>';

      rows += `
        <tr>
          <td class="font-mono text-secondary">${day.dateStr}</td>
          <td><strong>${day.dayLabel}</strong></td>
          <td class="font-mono">${waterDisplay}</td>
          <td>${pctBadge}</td>
          <td class="font-mono">${sleepDisplay}</td>
          <td>${starsDisplay}</td>
          <td>${scoreBadge}</td>
        </tr>
      `;
    });

    tableBody.innerHTML = rows;
  }
}

// Auto-initialize
if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => HistoryPageController.init());
  } else {
    HistoryPageController.init();
  }
}
