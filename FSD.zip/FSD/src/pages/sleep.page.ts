/**
 * Ezia Sleep Sanctuary Controller (src/pages/sleep.page.ts)
 * Strongly typed TypeScript controller for circadian rhythm logging,
 * midnight-crossing calculations, and restfulness tracking.
 */

import {
  StorageService,
  CalculatorService,
  SidebarController,
  DateBadge,
  Toast
} from '../index.js';
import { SleepLog, SleepRating } from '../types/health.js';

export class SleepPageController {
  private static currentRating: SleepRating = 4;
  private static readonly ratingLabels: Record<SleepRating, string> = {
    1: 'Restless',
    2: 'Fair',
    3: 'Moderate',
    4: 'Restful',
    5: 'Rejuvenated'
  };

  public static init(): void {
    if (typeof document === 'undefined') return;

    // 1. Navigation & Profile
    SidebarController.init();

    // 2. Date Badge
    DateBadge.init('sleepDateBadge');

    // 3. Live Duration Calculation on Input Changes
    const bedtimeInput = document.getElementById('bedtimeInput') as HTMLInputElement | null;
    const wakeTimeInput = document.getElementById('wakeTimeInput') as HTMLInputElement | null;

    [bedtimeInput, wakeTimeInput].forEach(inp => {
      inp?.addEventListener('input', () => this.updateDurationPreview());
    });

    // 4. Interactive Star Rating Selector
    const starPicker = document.getElementById('starRatingPicker');
    if (starPicker) {
      const stars = starPicker.querySelectorAll<HTMLButtonElement>('.star-btn');
      stars.forEach(btn => {
        btn.addEventListener('click', () => {
          const r = parseInt(btn.getAttribute('data-rating') || '4', 10) as SleepRating;
          this.setRating(r);
        });
      });
    }

    // 5. Sleep Form Submission
    const form = document.getElementById('sleepForm') as HTMLFormElement | null;
    if (form && bedtimeInput && wakeTimeInput) {
      form.addEventListener('submit', (e: SubmitEvent) => {
        e.preventDefault();
        const bedtime = bedtimeInput.value;
        const wakeTime = wakeTimeInput.value;
        const notesInput = document.getElementById('sleepNotesInput') as HTMLInputElement | null;
        const notes = notesInput ? notesInput.value.trim() : '';

        if (!bedtime || !wakeTime) {
          Toast.error('Please specify both bedtime and wake time.');
          return;
        }

        const durationHours = CalculatorService.calculateSleepDuration(bedtime, wakeTime);

        if (durationHours <= 0) {
          Toast.error('Calculated sleep duration must be greater than zero.');
          return;
        }

        const todayStr = new Date().toISOString().split('T')[0];

        StorageService.addSleepEntry({
          date: todayStr,
          bedtime,
          wakeTime,
          durationHours,
          restfulness: this.currentRating,
          notes
        });

        Toast.success(`Logged ${durationHours} hours of sleep`);
        if (notesInput) notesInput.value = '';
        this.render();
      });
    }

    // 6. Initial Duration Preview & Render
    this.updateDurationPreview();
    this.render();
  }

  private static updateDurationPreview(): void {
    const bedtimeInput = document.getElementById('bedtimeInput') as HTMLInputElement | null;
    const wakeTimeInput = document.getElementById('wakeTimeInput') as HTMLInputElement | null;
    const durationBadge = document.getElementById('calculatedDurationBadge');

    if (bedtimeInput && wakeTimeInput && durationBadge) {
      const b = bedtimeInput.value;
      const w = wakeTimeInput.value;
      if (b && w) {
        const dur = CalculatorService.calculateSleepDuration(b, w);
        durationBadge.textContent = `${dur} hrs`;
      }
    }
  }

  private static setRating(rating: SleepRating): void {
    this.currentRating = rating;
    const starPicker = document.getElementById('starRatingPicker');
    const descriptor = document.getElementById('ratingDescriptor');

    if (starPicker) {
      const stars = starPicker.querySelectorAll<HTMLButtonElement>('.star-btn');
      stars.forEach(btn => {
        const r = parseInt(btn.getAttribute('data-rating') || '0', 10);
        if (r <= rating) {
          btn.classList.add('active');
        } else {
          btn.classList.remove('active');
        }
      });
    }

    if (descriptor) {
      descriptor.innerHTML = `Rating: <strong>${rating} / 5 &mdash; ${this.ratingLabels[rating]}</strong>`;
    }
  }

  public static render(): void {
    const sleepLogs = StorageService.getSleepLogs();
    const heroDuration = document.getElementById('heroSleepDuration');
    const heroSchedule = document.getElementById('heroSleepSchedule');
    const tableBody = document.getElementById('sleepHistoryTableBody');

    // 1. Hero Sanctuary Overview
    if (sleepLogs.length > 0) {
      const latest = sleepLogs[0];
      if (heroDuration) heroDuration.textContent = String(latest.durationHours);
      if (heroSchedule) {
        heroSchedule.innerHTML = `
          Latest sleep session: <strong>${latest.bedtime}</strong> to <strong>${latest.wakeTime}</strong> (${latest.date}).<br>
          Subjective Quality: <strong>${this.ratingLabels[latest.restfulness] || 'Restful'}</strong>.
        `;
      }
    } else {
      if (heroDuration) heroDuration.textContent = '—';
      if (heroSchedule) heroSchedule.textContent = 'No sleep records logged yet.';
    }

    // 2. History Table
    if (tableBody) {
      if (sleepLogs.length === 0) {
        tableBody.innerHTML = `
          <tr>
            <td colspan="7" class="table-empty-cell">
              <div class="empty-state-wrap">
                <p class="empty-state-title">No sleep records logged yet</p>
                <p class="empty-state-sub">Enter your bedtime and morning wake time above to record your first session.</p>
              </div>
            </td>
          </tr>
        `;
      } else {
        let rows = '';
        sleepLogs.forEach(entry => {
          const stars = '★'.repeat(entry.restfulness) + '☆'.repeat(Math.max(0, 5 - entry.restfulness));
          rows += `
            <tr id="sleep-row-${entry.id}">
              <td class="font-mono text-secondary">${entry.date}</td>
              <td class="font-mono">${entry.bedtime}</td>
              <td class="font-mono">${entry.wakeTime}</td>
              <td><span class="badge badge-teal">${entry.durationHours} hrs</span></td>
              <td class="text-amber">${stars} <small class="text-muted">(${this.ratingLabels[entry.restfulness] || ''})</small></td>
              <td class="text-secondary">${entry.notes ? this.escapeHtml(entry.notes) : '<em class="text-muted">None</em>'}</td>
              <td>
                <button type="button" class="btn-delete-row" data-id="${entry.id}" title="Remove record" aria-label="Delete sleep record">✕</button>
              </td>
            </tr>
          `;
        });
        tableBody.innerHTML = rows;

        tableBody.querySelectorAll<HTMLButtonElement>('.btn-delete-row').forEach(btn => {
          btn.addEventListener('click', () => {
            const id = btn.getAttribute('data-id');
            if (id) {
              StorageService.deleteSleepEntry(id);
              Toast.info('Sleep record removed');
              this.render();
            }
          });
        });
      }
    }
  }

  private static escapeHtml(str: string): string {
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
}

// Auto-initialize
if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => SleepPageController.init());
  } else {
    SleepPageController.init();
  }
}
