/**
 * Ezia Hydration Vessel Controller (src/pages/hydration.page.ts)
 * Strongly typed TypeScript controller for fluid tracking and vessel physics.
 */

import {
  StorageService,
  SidebarController,
  DateBadge,
  Toast
} from '../index.js';
import { HydrationLog } from '../types/health.js';

export class HydrationPageController {
  public static init(): void {
    if (typeof document === 'undefined') return;

    // 1. Reusable Navigation & Profile
    SidebarController.init();

    // 2. Date Badge
    DateBadge.init('hydrationDateBadge');

    // 3. Quick-Add Buttons
    const quickBtns = document.querySelectorAll<HTMLButtonElement>('.quick-btn');
    quickBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const ml = parseInt(btn.getAttribute('data-ml') || '0', 10);
        if (ml > 0) {
          StorageService.addHydrationEntry(ml);
          Toast.success(`Logged +${ml} ml water`);
          this.render();
        }
      });
    });

    // 4. Custom Water Form
    const form = document.getElementById('customWaterForm') as HTMLFormElement | null;
    const input = document.getElementById('customAmountInput') as HTMLInputElement | null;
    if (form && input) {
      form.addEventListener('submit', (e: SubmitEvent) => {
        e.preventDefault();
        const val = parseInt(input.value, 10);
        if (!isNaN(val) && val > 0 && val <= 5000) {
          StorageService.addHydrationEntry(val);
          Toast.success(`Logged +${val} ml water`);
          input.value = '';
          this.render();
        } else {
          Toast.warning('Please enter a valid volume between 20 and 5000 ml.');
        }
      });
    }

    // 5. Undo Last Button
    const undoBtn = document.getElementById('undoLastWaterBtn');
    if (undoBtn) {
      undoBtn.addEventListener('click', () => {
        const todayStr = new Date().toISOString().split('T')[0];
        const logs = StorageService.getHydrationLogs().filter(item => item.date === todayStr);
        if (logs.length > 0) {
          const lastId = logs[0].id;
          StorageService.deleteHydrationEntry(lastId);
          Toast.info('Reverted last hydration entry');
          this.render();
        } else {
          Toast.warning('No entries available to undo for today.');
        }
      });
    }

    // 6. Initial Render
    this.render();
  }

  public static render(): void {
    const todayStr = new Date().toISOString().split('T')[0];
    const profile = StorageService.getProfile();
    const waterGoal = profile.waterGoalMl || 2500;

    const allLogs = StorageService.getHydrationLogs();
    const todayLogs = allLogs.filter(item => item.date === todayStr);
    const totalWater = todayLogs.reduce((sum, item) => sum + item.amountMl, 0);

    const percent = Math.min(100, Math.round((totalWater / waterGoal) * 100));
    const remaining = Math.max(0, waterGoal - totalWater);

    // DOM Elements
    const totalWaterText = document.getElementById('totalWaterText');
    const waterGoalSummary = document.getElementById('waterGoalSummary');
    const waterRemainingText = document.getElementById('waterRemainingText');
    const liquidWaveFill = document.getElementById('liquidWaveFill');
    const hydrationStatusBadge = document.getElementById('hydrationStatusBadge');
    const logsListContainer = document.getElementById('hydrationLogsList');

    if (totalWaterText) totalWaterText.textContent = totalWater.toLocaleString();
    if (waterGoalSummary) {
      waterGoalSummary.textContent = `${percent}% of your ${waterGoal.toLocaleString()} ml personal target`;
    }
    if (waterRemainingText) waterRemainingText.textContent = `${remaining.toLocaleString()} ml`;

    if (liquidWaveFill) {
      liquidWaveFill.style.height = `${Math.min(100, percent)}%`;
    }

    if (hydrationStatusBadge) {
      if (totalWater === 0) {
        hydrationStatusBadge.textContent = 'Awaiting Intake';
        hydrationStatusBadge.className = 'badge badge-amber';
      } else if (totalWater >= waterGoal) {
        hydrationStatusBadge.textContent = 'Target Achieved';
        hydrationStatusBadge.className = 'badge badge-mint';
      } else {
        hydrationStatusBadge.textContent = 'Hydrating';
        hydrationStatusBadge.className = 'badge badge-teal';
      }
    }

    // Render Timeline Ledger
    if (logsListContainer) {
      if (todayLogs.length === 0) {
        logsListContainer.innerHTML = `
          <div class="empty-state-wrap">
            <img src="./assets/illustrations/empty-state.svg" alt="" width="64" height="64" class="empty-state-icon">
            <p class="empty-state-title">No fluids logged for today yet</p>
            <p class="empty-state-sub">Tap a preset button (+250 ml or +500 ml) above to record your first intake.</p>
          </div>
        `;
      } else {
        let html = '';
        todayLogs.forEach(entry => {
          html += `
            <div class="log-item" id="log-${entry.id}">
              <div class="log-item-left">
                <span class="log-dot"></span>
                <span class="log-time">${entry.time || 'Logged'}</span>
              </div>
              <div class="log-item-right">
                <strong class="log-amount text-teal">+${entry.amountMl.toLocaleString()} ml</strong>
                <button type="button" class="btn-delete-log" data-id="${entry.id}" title="Remove entry" aria-label="Delete entry">✕</button>
              </div>
            </div>
          `;
        });
        logsListContainer.innerHTML = html;

        // Bind delete listeners
        logsListContainer.querySelectorAll<HTMLButtonElement>('.btn-delete-log').forEach(delBtn => {
          delBtn.addEventListener('click', () => {
            const id = delBtn.getAttribute('data-id');
            if (id) {
              StorageService.deleteHydrationEntry(id);
              Toast.info('Intake entry removed');
              this.render();
            }
          });
        });
      }
    }
  }
}

// Auto-initialize
if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => HydrationPageController.init());
  } else {
    HydrationPageController.init();
  }
}
